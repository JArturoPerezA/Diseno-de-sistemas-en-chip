/**
 * twi.h
 * Definiciones para el controlador TWI (I2C) en modo maestro
 */

#ifndef TWI_H_
#define TWI_H_

#define F_CPU 8000000UL
#include <avr/io.h>                             // AVR IO lib File
#include <util/delay.h>                         // Delay Lib file
#include <util/twi.h>                           // TWI Status File
#include <math.h>                               // Math Func

#define SCL_CLK 400000L                         // SCL para TWI (400kHz)
// F�rmula de tasa de bits corregida para evitar errores de c�lculo en tiempo de compilaci�n
#define BITRATE(TWSR) ((F_CPU/SCL_CLK)-16)/(2*pow(4,(TWSR&((1<<TWPS0)|(1<<TWPS1)))))

// Prototipos de funciones TWI
void twi_init(void);
void twi_start(void);
void twi_repeated_start(void);
void twi_write_cmd(unsigned char address);
void twi_write_dwr(unsigned char val);
void twi_stop(void);
char twi_read_ack(void);
char twi_read_nack(void);

// Prototipos de funciones USART (para depuraci�n)
void usart_init(void);
void usart_tx(char x);
void usart_msg(char *c);
unsigned char usart_rx(void);

#endif /* TWI_H_ */