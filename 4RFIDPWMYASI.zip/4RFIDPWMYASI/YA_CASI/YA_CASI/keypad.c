/**
 * keypad.c - Versi�n corregida manteniendo el algoritmo original
 * Implementaci�n del manejo de teclado matricial 4x4 usando PORTA
 */

#include "keypad.h"
#include "twi_lcd.h"

void keypad_init(void) {
    // Configurar PA0-PA3 como salidas (filas) y PA4-PA7 como entradas (columnas)
    KEYPAD_DDR |= KEYPAD_ROWS;    // PA0-PA3 como salidas
    KEYPAD_DDR &= ~KEYPAD_COLS;   // PA4-PA7 como entradas
    
    // Habilitar resistencias pull-up en los pines de columnas (entradas)
    KEYPAD_PORT |= KEYPAD_COLS;
    
    // Inicialmente, todas las filas est�n en alto (inactivas)
    KEYPAD_PORT |= KEYPAD_ROWS;
}

uint8_t keypad_scan(void) {
    int cont_filas = 4;
    char codigo_barrido = 0b11111110;  // Comenzamos con la primera fila en bajo
    int valor_tecla = 3;  // Valor inicial corregido para mapeo correcto
    int temp;
    
    while (cont_filas != 0) {
        // Aplicar patr�n de escaneo manteniendo pull-ups en columnas
        // CORRECCI�N: Preservar el estado de las columnas (pull-ups)
        KEYPAD_PORT = (KEYPAD_PORT & KEYPAD_COLS) | (codigo_barrido & KEYPAD_ROWS);
        
        // CORRECCI�N: Peque�a pausa para estabilizar la se�al
        _delay_us(10);
        
        // Leer estado de columnas
        temp = KEYPAD_PIN & KEYPAD_COLS;
        
        if (temp == KEYPAD_COLS) {  // Ninguna tecla presionada (todas columnas en alto)
            codigo_barrido = (codigo_barrido << 1) | 1;
            valor_tecla = valor_tecla + 4;
            cont_filas--;
            
            if (cont_filas == 0) {
                valor_tecla = 0xFF;  // No hay tecla presionada
                break;
            }
        } else {
            // CORRECCI�N: Aumentar tiempo de debounce
            _delay_ms(20);  // Debounce m�s robusto
            temp = KEYPAD_PIN & KEYPAD_COLS;
            
            if (temp == KEYPAD_COLS) {
                valor_tecla = 0xFF;  // Detecci�n espuria
                break;
            } else if (temp == 0b01110000) {
                // No cambiar valor_tecla (primera columna)
            } else if (temp == 0b10110000) {
                valor_tecla = valor_tecla - 1;  // Segunda columna
            } else if (temp == 0b11010000) {
                valor_tecla = valor_tecla - 2;  // Tercera columna
            } else if (temp == 0b11100000) {
                valor_tecla = valor_tecla - 3;  // Cuarta columna
            } else {
                // CORRECCI�N: Manejar casos donde m�ltiples columnas est�n activas
                valor_tecla = 0xFF;  // Detecci�n inv�lida
                break;
            }
            
            // Esperar a que se suelte la tecla
            while ((KEYPAD_PIN & KEYPAD_COLS) != KEYPAD_COLS) {
                _delay_ms(1);  // CORRECCI�N: Peque�a pausa en el bucle de espera
            }
            
            _delay_ms(20);  // CORRECCI�N: Debounce despu�s de soltar (aumentado)
            cont_filas = 0;
        }
    }
    
    // Restaurar estado de filas (todas en alto)
    KEYPAD_PORT |= KEYPAD_ROWS;
    
    return valor_tecla;
}

// Mapear c�digos de escaneo a caracteres - CORREGIDO con columnas invertidas
char keypad_map_to_char(uint8_t key_code) {
    // Mapeo corregido - las columnas est�n f�sicamente invertidas
    // El algoritmo original cuenta desde 3 y va incrementando
    switch (key_code) {
        case 0:  return '1';  // Fila 0, Columna 3 (f�sicamente columna 0)
        case 1:  return '2';  // Fila 0, Columna 2 (f�sicamente columna 1)
        case 2:  return '3';  // Fila 0, Columna 1 (f�sicamente columna 2)
        case 3:  return 'A';  // Fila 0, Columna 0 (f�sicamente columna 3)
        case 4:  return '4';  // Fila 1, Columna 3 (f�sicamente columna 0)
        case 5:  return '5';  // Fila 1, Columna 2 (f�sicamente columna 1)
        case 6:  return '6';  // Fila 1, Columna 1 (f�sicamente columna 2)
        case 7:  return 'B';  // Fila 1, Columna 0 (f�sicamente columna 3)
        case 8:  return '7';  // Fila 2, Columna 3 (f�sicamente columna 0)
        case 9:  return '8';  // Fila 2, Columna 2 (f�sicamente columna 1)
        case 10: return '9';  // Fila 2, Columna 1 (f�sicamente columna 2)
        case 11: return 'C';  // Fila 2, Columna 0 (f�sicamente columna 3)
        case 12: return '*';  // Fila 3, Columna 3 (f�sicamente columna 0)
        case 13: return '0';  // Fila 3, Columna 2 (f�sicamente columna 1)
        case 14: return '#';  // Fila 3, Columna 1 (f�sicamente columna 2)
        case 15: return 'D';  // Fila 3, Columna 0 (f�sicamente columna 3)
        default: return 0;    // Car�cter nulo para c�digos inv�lidos
    }
}

// Variables globales para almacenar los datos
char user_type = 0;          // 'A' para estudiante, 'B' para colaborador
char user_number[17] = {0};  // N�mero de matr�cula o n�mina

// Funci�n para obtener tipo de usuario y n�mero
void keypad_get_input(void) {
	uint8_t key;
	char key_char;
	char input_buffer[17] = {0};
	uint8_t input_pos = 0;
	
	// PASO 1: Preguntar tipo de usuario
	twi_lcd_cmd(0x01);  // Limpiar pantalla
	_delay_ms(2);
	
	twi_lcd_msg("Seleccione usuario:");
	
	twi_lcd_cmd(0x94);  // L�nea 2
	twi_lcd_msg("A = Estudiante");
	
	twi_lcd_cmd(0xD4);  // L�nea 3
	twi_lcd_msg("B = Colaborador");
	
	// Esperar a que presione A o B
	while (1) {
		key = keypad_scan();
		
		if (key != 0xFF) {
			key_char = keypad_map_to_char(key);
			
			if (key_char == 'A') {
				user_type = 'A';
				break;
				} else if (key_char == 'B') {
				user_type = 'B';
				break;
			}
		}
		_delay_ms(50);
	}
	
	// PASO 2: Mostrar mensaje seg�n el tipo de usuario
	twi_lcd_cmd(0x01);
	_delay_ms(2);
	
	if (user_type == 'A') {
		twi_lcd_msg("Ingrese matricula:");
		} else {
		twi_lcd_msg("Ingrese nomina:");
	}
	
	twi_lcd_cmd(0x94);  // L�nea 2
	twi_lcd_msg("Debe iniciar con 0");
	
	twi_lcd_cmd(0x14);  // L�nea 4
	twi_lcd_msg("*=Borrar  #=Aceptar");
	
	_delay_ms(2000);
	
	// Preparar pantalla para captura
	twi_lcd_cmd(0x01);
	_delay_ms(2);
	
	if (user_type == 'A') {
		twi_lcd_msg("Matricula: ");
		} else {
		twi_lcd_msg("Nomina: ");
	}
	
	// PASO 3: Capturar el n�mero
	input_pos = 0;
	memset(input_buffer, 0, sizeof(input_buffer));
	uint8_t first_digit_entered = 0;
	
	while (1) {
		key = keypad_scan();
		
		if (key != 0xFF) {
			key_char = keypad_map_to_char(key);
			
			if (key_char == 0) {
				continue;  // Ignorar caracteres inv�lidos
			}
			
			// Si se presion� #, guardar y salir
			if (key_char == '#') {
				if (input_pos > 0) {
					strcpy(user_number, input_buffer);
					break;
					} else {
					// Error si no hay entrada
					twi_lcd_cmd(0xD4);  // L�nea 3
					twi_lcd_msg("Ingrese un numero");
					_delay_ms(1500);
					twi_lcd_cmd(0xD4);
					twi_lcd_msg("                    ");
					continue;
				}
			}
			
			// Tecla * para borrar
			if (key_char == '*' && input_pos > 0) {
				input_pos--;
				input_buffer[input_pos] = 0;
				
				if (input_pos == 0) {
					first_digit_entered = 0;
				}
				
				// Actualizar visualizaci�n
				twi_lcd_cmd(0x80 + 11);  // Volver a posici�n inicial
				twi_lcd_msg("                ");
				twi_lcd_cmd(0x80 + 11);
				if (input_pos > 0) {
					twi_lcd_msg(input_buffer);
				}
			}
			// Entrada de n�meros
			else if (key_char >= '0' && key_char <= '9' && input_pos < 16) {
				// Verificar primer d�gito sea '0'
				if (!first_digit_entered) {
					if (key_char != '0') {
						twi_lcd_cmd(0xD4);  // L�nea 3
						twi_lcd_msg("Debe iniciar con 0");
						_delay_ms(1500);
						twi_lcd_cmd(0xD4);
						twi_lcd_msg("                    ");
						continue;
					}
					first_digit_entered = 1;
				}
				
				// A�adir al buffer
				input_buffer[input_pos] = key_char;
				input_pos++;
				input_buffer[input_pos] = 0;
				
				// Actualizar LCD
				twi_lcd_cmd(0x80 + 11);  // Posici�n del n�mero
				twi_lcd_msg(input_buffer);
			}
		}
		
		_delay_ms(50);
	}
	
	// PASO 4: Mostrar confirmaci�n
	twi_lcd_cmd(0x01);
	_delay_ms(2);
	
	if (user_type == 'A') {
		twi_lcd_msg("Estudiante:");
		} else {
		twi_lcd_msg("Colaborador:");
	}
	
	twi_lcd_cmd(0x94);  // L�nea 2
	twi_lcd_msg(user_number);
	
	twi_lcd_cmd(0xD4);  // L�nea 3
	twi_lcd_msg("Registro completado");
	
	_delay_ms(3000);
}

// Funci�n para obtener el tipo de usuario guardado
char keypad_get_user_type(void) {
	return user_type;
}

// Funci�n para obtener el n�mero guardado
char* keypad_get_user_number(void) {
	return user_number;
}

// FUNCI�N DE DEBUG: Simplificada
void keypad_debug_scan(void) {
	twi_lcd_cmd(0x01);
	twi_lcd_msg("Debug Teclado");
	_delay_ms(1000);
	
	while (1) {
		uint8_t key = keypad_scan();
		if (key != 0xFF) {
			char key_char = keypad_map_to_char(key);
			
			twi_lcd_cmd(0x01);
			twi_lcd_msg("Codigo: ");
			
			// Mostrar c�digo
			char code_str[4];
			sprintf(code_str, "%02d", key);
			twi_lcd_msg(code_str);
			
			twi_lcd_cmd(0x94);  // L�nea 2
			twi_lcd_msg("Tecla: ");
			if (key_char != 0) {
				char char_str[2] = {key_char, 0};
				twi_lcd_msg(char_str);
				} else {
				twi_lcd_msg("INVALIDO");
			}
			
			_delay_ms(1500);
		}
		_delay_ms(50);
	}
}

