/**
 * mfrc522.c
 * Implementaci�n de funciones para control de lectores RFID MFRC522
 */

#include "mfrc522.h"
#include <avr/io.h>

// Variables globales para almacenar las UIDs de ambos lectores
static Uid cardUID1;    // UID del primer lector (control de acceso)
static Uid cardUID2;    // UID del segundo lector (detecci�n)

// Obtener puntero a la UID correspondiente al lector
Uid* getCardUID(uint8_t reader) {
    if (reader == 1) {
        return &cardUID1;
    } else {
        return &cardUID2;
    }
}

// Funci�n para seleccionar el lector activo
void selectReader(uint8_t reader) {
    if (reader == 1) {
        PORTB &= ~(1<<SS1_PIN);  // SS1 low
        PORTB |= (1<<SS2_PIN);   // SS2 high
    } else if (reader == 2) {
        PORTB |= (1<<SS1_PIN);   // SS1 high
        PORTB &= ~(1<<SS2_PIN);  // SS2 low
    }
}

// Inicializaci�n SPI
void SPI_Init(void) {
    DDRB |= (1<<MOSI_PIN)|(1<<SCK_PIN)|(1<<SS1_PIN)|(1<<SS2_PIN);
    DDRB &= ~(1<<MISO_PIN);
    DDRD |= (1<<RST_PIN);
    
    PORTB |= (1<<SS1_PIN)|(1<<SS2_PIN);
    
    SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0);
}

// Transferencia SPI
uint8_t SPI_Transfer(uint8_t data) {
    SPDR = data;
    while(!(SPSR & (1<<SPIF)));
    return SPDR;
}

// Inicializar lector MFRC522
void MFRC522_Init(uint8_t reader) {
    MFRC522_Reset(reader);
    
    MFRC522_WriteRegister(TModeReg, 0x8D, reader);
    MFRC522_WriteRegister(TPrescalerReg, 0x3E, reader);
    MFRC522_WriteRegister(TReloadRegL, 30, reader);
    MFRC522_WriteRegister(TReloadRegH, 0, reader);
    
    MFRC522_WriteRegister(TxAutoReg, 0x40, reader);
    MFRC522_WriteRegister(ModeReg, 0x3D, reader);
    
    MFRC522_AntennaOn(reader);
}

// Resetear lector MFRC522
void MFRC522_Reset(uint8_t reader) {
    MFRC522_WriteRegister(CommandReg, PCD_RESETPHASE, reader);
}

// Leer registro de MFRC522
uint8_t MFRC522_ReadRegister(uint8_t reg, uint8_t reader) {
    uint8_t value;
    selectReader(reader);
    SPI_Transfer(((reg<<1)&0x7E)|0x80);
    value = SPI_Transfer(0x00);
    PORTB |= (1<<SS1_PIN)|(1<<SS2_PIN);
    return value;
}

// Escribir registro de MFRC522
void MFRC522_WriteRegister(uint8_t reg, uint8_t value, uint8_t reader) {
    selectReader(reader);
    SPI_Transfer((reg<<1)&0x7E);
    SPI_Transfer(value);
    PORTB |= (1<<SS1_PIN)|(1<<SS2_PIN);
}

// Establecer m�scara de bits en registro
void MFRC522_SetBitMask(uint8_t reg, uint8_t mask, uint8_t reader) {
    uint8_t tmp = MFRC522_ReadRegister(reg, reader);
    MFRC522_WriteRegister(reg, tmp | mask, reader);
}

// Limpiar m�scara de bits en registro
void MFRC522_ClearBitMask(uint8_t reg, uint8_t mask, uint8_t reader) {
    uint8_t tmp = MFRC522_ReadRegister(reg, reader);
    MFRC522_WriteRegister(reg, tmp & (~mask), reader);
}

// Encender antena
void MFRC522_AntennaOn(uint8_t reader) {
    uint8_t temp = MFRC522_ReadRegister(TxControlReg, reader);
    if (!(temp & 0x03)) {
        MFRC522_SetBitMask(TxControlReg, 0x03, reader);
    }
}

// Comunicaci�n con tarjeta
uint8_t MFRC522_ToCard(uint8_t command, uint8_t *sendData, uint8_t sendLen, uint8_t *backData, uint16_t *backLen, uint8_t reader) {
    uint8_t status = MI_ERR;
    uint8_t irqEn = 0x00;
    uint8_t waitIRq = 0x00;
    uint8_t lastBits;
    uint8_t n;
    uint16_t i;
    
    switch (command) {
        case PCD_AUTHENT:
            irqEn = 0x12;
            waitIRq = 0x10;
            break;
        case PCD_TRANSCEIVE:
            irqEn = 0x77;
            waitIRq = 0x30;
            break;
        default:
            break;
    }
    
    MFRC522_WriteRegister(ComIEnReg, irqEn|0x80, reader);
    MFRC522_ClearBitMask(ComIrqReg, 0x80, reader);
    MFRC522_SetBitMask(FIFOLevelReg, 0x80, reader);
    
    MFRC522_WriteRegister(CommandReg, PCD_IDLE, reader);
    
    for (i=0; i<sendLen; i++) {
        MFRC522_WriteRegister(FIFODataReg, sendData[i], reader);
    }
    
    MFRC522_WriteRegister(CommandReg, command, reader);
    if (command == PCD_TRANSCEIVE) {
        MFRC522_SetBitMask(BitFramingReg, 0x80, reader);
    }
    
    i = 2000;
    do {
        n = MFRC522_ReadRegister(ComIrqReg, reader);
        i--;
    } while ((i!=0) && !(n&0x01) && !(n&waitIRq));
    
    MFRC522_ClearBitMask(BitFramingReg, 0x80, reader);
    
    if (i != 0) {
        if(!(MFRC522_ReadRegister(ErrorReg, reader) & 0x1B)) {
            status = MI_OK;
            if (n & irqEn & 0x01) {
                status = MI_NOTAGERR;
            }
            
            if (command == PCD_TRANSCEIVE) {
                n = MFRC522_ReadRegister(FIFOLevelReg, reader);
                lastBits = MFRC522_ReadRegister(ControlReg, reader) & 0x07;
                if (lastBits) {
                    *backLen = (n-1)*8 + lastBits;
                } else {
                    *backLen = n*8;
                }
                
                if (n == 0) {
                    n = 1;
                }
                if (n > 16) {
                    n = 16;
                }
                
                for (i=0; i<n; i++) {
                    backData[i] = MFRC522_ReadRegister(FIFODataReg, reader);
                }
            }
        } else {
            status = MI_ERR;
        }
    }
    
    return status;
}

// Enviar solicitud de tarjeta
uint8_t MFRC522_Request(uint8_t reqMode, uint8_t *TagType, uint8_t reader) {
    uint8_t status;
    uint16_t backBits;
    
    MFRC522_WriteRegister(BitFramingReg, 0x07, reader);
    
    TagType[0] = reqMode;
    status = MFRC522_ToCard(PCD_TRANSCEIVE, TagType, 1, TagType, &backBits, reader);
    
    if ((status != MI_OK) || (backBits != 0x10)) {
        status = MI_ERR;
    }
    
    return status;
}

// Funci�n de anti-colisi�n
uint8_t MFRC522_Anticoll(uint8_t *serNum, uint8_t reader) {
    uint8_t status;
    uint8_t i;
    uint8_t serNumCheck=0;
    uint16_t unLen;
    
    MFRC522_WriteRegister(BitFramingReg, 0x00, reader);
    
    serNum[0] = PICC_CMD_SEL_CL1;
    serNum[1] = 0x20;
    status = MFRC522_ToCard(PCD_TRANSCEIVE, serNum, 2, serNum, &unLen, reader);
    
    if (status == MI_OK) {
        for (i=0; i<4; i++) {
            serNumCheck ^= serNum[i];
        }
        if (serNumCheck != serNum[i]) {
            status = MI_ERR;
        }
    }
    
    return status;
}

// Verificar si hay nueva tarjeta presente
uint8_t MFRC522_IsNewCardPresent(uint8_t reader) {
    uint8_t status;
    uint8_t TagType[2];
    
    status = MFRC522_Request(PICC_CMD_REQA, TagType, reader);
    if (status == MI_OK) {
        return 1;
    } else {
        return 0;
    }
}

// Leer n�mero de serie de tarjeta
uint8_t MFRC522_ReadCardSerial(uint8_t reader) {
    uint8_t status;
    uint8_t serNum[5];
    uint8_t i;
    
    status = MFRC522_Anticoll(serNum, reader);
    if (status == MI_OK) {
        // Guardar la UID en la variable correspondiente al lector
        if (reader == 1) {
            cardUID1.size = 4; // UID de 4 bytes para tarjetas MIFARE Classic
            for (i = 0; i < 4; i++) {
                cardUID1.uidByte[i] = serNum[i];
            }
        } else if (reader == 2) {
            cardUID2.size = 4; // UID de 4 bytes para tarjetas MIFARE Classic
            for (i = 0; i < 4; i++) {
                cardUID2.uidByte[i] = serNum[i];
            }
        }
        return 1;
    } else {
        return 0;
    }
}