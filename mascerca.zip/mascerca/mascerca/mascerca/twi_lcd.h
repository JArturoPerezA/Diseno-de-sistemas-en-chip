/**
 * twi_lcd.h
 * Definiciones para el control de LCD a trav�s de TWI usando el chip PCF8574
 * 
 * PCF8574 tiene un puerto de 8 bits para operaciones de E/S
 * P0 = RS;       // Selecci�n de registro
 * P1 = RW;       // Selecci�n de operaci�n de lectura/escritura
 * P2 = EN;       // Pin de habilitaci�n para bloquear el registro de datos
 * P3 = Backlight; // Control de retroiluminaci�n LCD
 * P4 = D4;       // Pin D4 de LCD
 * P5 = D5;       // Pin D5 de LCD
 * P6 = D6;       // Pin D6 de LCD
 * P7 = D7;       // Pin D7 de LCD
 */

#ifndef TWI_LCD_H_
#define TWI_LCD_H_

#include <avr/io.h>
#include "twi.h"

#define PCF8574 0x27                            // La direcci�n del esclavo es de 7 bits
#define WRITE   0
#define READ    1

// Prototipos de funciones
void PCF8574_write(unsigned char x);
void twi_lcd_4bit_send(unsigned char x);
void twi_lcd_cmd(unsigned char x);
void twi_lcd_dwr(unsigned char x);
void twi_lcd_msg(char *c);
void twi_lcd_clear(void);
void twi_lcd_init(void);

#endif /* TWI_LCD_H_ */