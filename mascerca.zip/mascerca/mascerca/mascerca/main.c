/**
 * main.c
 * Sistema de control dual RFID con ATmega16
 * 
 * Este archivo contiene la funci�n principal y la l�gica del sistema
 */

#define F_CPU 8000000UL  // 8 MHz

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <string.h>
#include "twi_lcd.h"
#include "mfrc522.h"
#include "eeprom_manager.h"
#include "lcd_utils.h"

// Definici�n del pin para LED de detecci�n sensor 2
#define LED_PIN     PD7

// Variables globales
uint8_t ledTimer = 0;  // Contador para apagar el LED despu�s de un tiempo

// Inicializar LED
void LED_Init(void) {
    DDRD |= (1<<LED_PIN);  // Configurar pin del LED como salida
    LED_Off();             // Inicialmente apagado
}

void LED_On(void) {
    PORTD |= (1<<LED_PIN);
}

void LED_Off(void) {
    PORTD &= ~(1<<LED_PIN);
}

// Funci�n de prueba para el sensor 2
void testSensor2(void) {
    uint8_t version;
    
    // Leer versi�n del sensor 2
    version = MFRC522_ReadRegister(VersionReg, 2);
    
    twi_lcd_cmd(0x01);
    twi_lcd_msg("Test Sensor 2:");
    twi_lcd_cmd(0xC0);
    
    if (version == 0x91 || version == 0x92) {
        twi_lcd_msg("OK - Version:");
        char hex[3];
        byteToHex(version, hex);
        twi_lcd_msg(hex);
    } else if (version == 0x00 || version == 0xFF) {
        twi_lcd_msg("Error conexion");
    } else {
        twi_lcd_msg("Version:");
        char hex[3];
        byteToHex(version, hex);
        twi_lcd_msg(hex);
    }
    
    _delay_ms(2000);
}

int main(void) {
    // Inicializaci�n
    twi_init();                 // TWI Initialize
    twi_lcd_init();             // TWI LCD Initialize
    SPI_Init();                 // SPI Initialize
    LED_Init();                 // LED Initialize
    
    // Inicializar ambos lectores RFID
    MFRC522_Init(1);            // Inicializar primer lector (control de acceso)
    MFRC522_Init(2);            // Inicializar segundo lector (detecci�n)
    
    // Inicializar EEPROM para control de acceso
    initializeEEPROM();
    
    // Mostrar mensaje inicial
    twi_lcd_cmd(0x01);          // Clear display
    twi_lcd_msg("Sistema Dual");
    twi_lcd_cmd(0xC0);          // Segunda l�nea
    twi_lcd_msg("RFID Iniciando...");
    
    _delay_ms(2000);
    
    // Probar sensor 2
    testSensor2();
    
    // Mostrar cantidad de UIDs autorizadas
    displayAuthorizedCount();
    _delay_ms(2000);
    
    // Mostrar mensaje de operaci�n normal
    twi_lcd_cmd(0x01);
    twi_lcd_msg("S1:Acceso S2:Det");
    twi_lcd_cmd(0xC0);
    twi_lcd_msg("Esperando...");
    
    uint8_t card1Present = 0;
    uint8_t card2Present = 0;
    uint8_t displayTimer = 0;
    uint8_t sensor1Busy = 0;
    
    while(1) {
        // Solo verificar sensores si no hay operaci�n en curso
        if (!sensor1Busy) {
            // Verificar primer lector (Control de acceso)
            if (MFRC522_IsNewCardPresent(1)) {
                if (MFRC522_ReadCardSerial(1)) {
                    sensor1Busy = 1;  // Marcar sensor 1 como ocupado
                    card1Present = 1;
                    
                    // Mostrar UID del sensor 1
                    displayUID_LCD(1);
                    _delay_ms(1500);
                    
                    // Verificar autorizaci�n
                    uint8_t access_granted = checkUID_Authorization();
                    
                    // Mostrar resultado del acceso
                    displayAccessResult(access_granted);
                    _delay_ms(2000);
                    
                    // Si no est� autorizada, preguntar si se desea agregar
                    if (!access_granted) {
                        twi_lcd_cmd(0x01);
                        twi_lcd_msg("Agregar UID?");
                        twi_lcd_cmd(0xC0);
                        twi_lcd_msg("Espere 3s = SI");
                        
                        _delay_ms(3000);
                        
                        if (addUID_ToEEPROM(getCardUID(1)->uidByte)) {
                            twi_lcd_cmd(0x01);
                            twi_lcd_msg("UID Agregada!");
                            twi_lcd_cmd(0xC0);
                            twi_lcd_msg("Exitosamente");
                        } else {
                            twi_lcd_cmd(0x01);
                            twi_lcd_msg("Memoria llena!");
                            twi_lcd_cmd(0xC0);
                            twi_lcd_msg("No se agrego");
                        }
                        _delay_ms(2000);
                        
                        displayAuthorizedCount();
                        _delay_ms(2000);
                    }
                    
                    displayTimer = 50; // Mantener display por 5 segundos
                    sensor1Busy = 0;  // Liberar sensor 1
                    
                    // Peque�a pausa antes de continuar
                    _delay_ms(500);
                }
            }
            
            // Verificar segundo lector solo si sensor 1 no est� ocupado
            if (!sensor1Busy && MFRC522_IsNewCardPresent(2)) {
                if (MFRC522_ReadCardSerial(2)) {
                    card2Present = 1;
                    
                    // Encender LED
                    LED_On();
                    ledTimer = 30; // Mantener LED encendido por 3 segundos
                    
                    // Mostrar detecci�n en LCD si no hay operaci�n del sensor 1
                    if (displayTimer == 0) {
                        twi_lcd_cmd(0x01);
                        twi_lcd_msg("Sensor 2: Detect");
                        twi_lcd_cmd(0xC0);
                        twi_lcd_msg("LED Activado");
                        displayTimer = 20; // Mostrar por 2 segundos
                    }
                    
                    // Peque�a pausa antes de continuar
                    _delay_ms(500);
                }
            }
        }
        
        // Control del temporizador del LED
        if (ledTimer > 0) {
            ledTimer--;
            if (ledTimer == 0) {
                LED_Off();
            }
        }
        
        // Control del temporizador del display
        if (displayTimer > 0) {
            displayTimer--;
            if (displayTimer == 0) {
                // Restaurar mensaje normal
                twi_lcd_cmd(0x01);
                twi_lcd_msg("S1:Acceso S2:Det");
                twi_lcd_cmd(0xC0);
                twi_lcd_msg("Esperando...");
                card1Present = 0;
                card2Present = 0;
            }
        }
        
        _delay_ms(100); // Pausa de 100ms entre iteraciones
    }
    
    return 0;
}