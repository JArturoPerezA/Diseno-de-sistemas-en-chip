/*
   4x4 Keypad Interfacing with ATmega16/32 + EEPROM Storage
   http://www.electronicwings.com
 */ 
#include "LCD16x2_4bit.h"
#include <avr/io.h>
#include <util/delay.h>
#include <avr/eeprom.h>

#define KEY_PRT 	PORTA
#define KEY_DDR		DDRA
#define KEY_PIN		PINA

// Direcci�n base en EEPROM para guardar n�meros de tel�fono
#define EEPROM_BASE_ADDR 0x00
#define MAX_PHONE_LENGTH 16

unsigned char keypad[4][4] = {	{'7','8','9','/'},
								{'4','5','6','*'},
								{'1','2','3','-'},
								{' ','0','=','+'}};

unsigned char colloc, rowloc;
char phone_buffer[MAX_PHONE_LENGTH + 1]; // Buffer para el n�mero + null terminator

char keyfind()
{
	while(1)
	{
		KEY_DDR = 0xF0;                /* set port direction as input-output */
		KEY_PRT = 0xFF;
		do
		{
			KEY_PRT &= 0x0F;           /* mask PORT for column read only */
			asm("NOP");
			colloc = (KEY_PIN & 0x0F); /* read status of column */
		}while(colloc != 0x0F);
		
		do
		{
			do
			{
				_delay_ms(20);			   /* 20ms key debounce time */
				colloc = (KEY_PIN & 0x0F); /* read status of column */
			}while(colloc == 0x0F);        /* check for any key press */
			
			_delay_ms(40);				   /* 20 ms key debounce time */
			colloc = (KEY_PIN & 0x0F);
		}while(colloc == 0x0F);
	/* now check for rows */
		KEY_PRT = 0xEF;            /* check for pressed key in 1st row */
		asm("NOP");
		colloc = (KEY_PIN & 0x0F);
		if(colloc != 0x0F)
		{
			rowloc = 0;
			break;
		}
		KEY_PRT = 0xDF;			  /* check for pressed key in 2nd row */
		asm("NOP");
		colloc = (KEY_PIN & 0x0F);
		if(colloc != 0x0F)
		{
			rowloc = 1;
			break;
		}
		
		KEY_PRT = 0xBF;			  /* check for pressed key in 3rd row */
		asm("NOP");
		colloc = (KEY_PIN & 0x0F);
		if(colloc != 0x0F)
		{
			rowloc = 2;
			break;
		}
		KEY_PRT = 0x7F;			  /* check for pressed key in 4th row */
		asm("NOP");
		colloc = (KEY_PIN & 0x0F);
		if(colloc != 0x0F)
		{
			rowloc = 3;
			break;
		}
	}
	if(colloc == 0x0E)
		return(keypad[rowloc][0]);
	else if(colloc == 0x0D)
		return(keypad[rowloc][1]);
	else if(colloc == 0x0B)
		return(keypad[rowloc][2]);
	else
		return(keypad[rowloc][3]);
}

// Funci�n para guardar el n�mero de tel�fono en EEPROM
void save_phone_to_eeprom(char* phone_number, uint8_t length)
{
	// Guardar la longitud del n�mero primero
	eeprom_write_byte((uint8_t*)EEPROM_BASE_ADDR, length);
	
	// Guardar el n�mero de tel�fono
	for(uint8_t i = 0; i < length; i++)
	{
		eeprom_write_byte((uint8_t*)(EEPROM_BASE_ADDR + 1 + i), phone_number[i]);
	}
	
	// Mostrar confirmaci�n en LCD
	LCD_Command(0x01);        // Limpiar pantalla
	_delay_ms(2);
	LCD_String_xy(0,0,"Guardado!");
	_delay_ms(1000);          // Mostrar mensaje por 1 segundo
	
	// Limpiar pantalla y mostrar mensaje principal
	LCD_Command(0x01);        // Limpiar pantalla
	_delay_ms(2);
	LCD_String_xy(0,0,"Num telefono:");
}

// Funci�n para leer el n�mero de tel�fono desde EEPROM (solo para verificar)
void load_phone_from_eeprom()
{
	// Leer la longitud del n�mero guardado
	uint8_t length = eeprom_read_byte((uint8_t*)EEPROM_BASE_ADDR);
	
	if(length > 0 && length <= MAX_PHONE_LENGTH)
	{
		LCD_Command(0x01);        // Limpiar pantalla
		_delay_ms(2);
		LCD_String_xy(0,0,"Ultimo numero:");
		
		// Leer y mostrar el n�mero guardado
		for(uint8_t i = 0; i < length; i++)
		{
			char digit = eeprom_read_byte((uint8_t*)(EEPROM_BASE_ADDR + 1 + i));
			LCD_Command(0xC0 + i); // Posicionar cursor en l�nea 2
			LCD_Char(digit);
		}
		_delay_ms(3000);          // Mostrar por 3 segundos
	}
	else
	{
		LCD_Command(0x01);        // Limpiar pantalla
		_delay_ms(2);
		LCD_String_xy(0,0,"No hay numeros");
		LCD_String_xy(1,0,"guardados");
		_delay_ms(2000);
	}
}

int main(void)
{
	LCD_Init();
	_delay_ms(100);           // Esperar a que se inicialice el LCD
	
	// Pantalla principal directa - NO mostrar n�meros guardados al inicio
	LCD_Command(0x01);        // Limpiar pantalla
	_delay_ms(2);
	LCD_String_xy(0,0,"Num telefono:");
	
	uint8_t pos = 0;  // Posici�n en la segunda l�nea (0 a 15)
	
	// Limpiar buffer
	for(uint8_t i = 0; i < MAX_PHONE_LENGTH; i++)
	{
		phone_buffer[i] = 0;
	}
	
	while(1)
	{
		char key = keyfind();
		
		if (key == ' ')  // Si se presiona la tecla ON/C (espacio) - Limpiar
		{
			LCD_Command(0x01);        // Limpiar pantalla
			_delay_ms(2);
			LCD_String_xy(0,0,"Num telefono:");
			pos = 0;                  // Reiniciar posici�n
			
			// Limpiar buffer
			for(uint8_t i = 0; i < MAX_PHONE_LENGTH; i++)
			{
				phone_buffer[i] = 0;
			}
		}
		else if (key == '=')  // Si se presiona '=' - Guardar en EEPROM y limpiar
		{
			if(pos > 0)  // Solo guardar si hay algo que guardar
			{
				save_phone_to_eeprom(phone_buffer, pos);
				pos = 0;                  // Reiniciar posici�n
				
				// Limpiar buffer
				for(uint8_t i = 0; i < MAX_PHONE_LENGTH; i++)
				{
					phone_buffer[i] = 0;
				}
			}
		}
		else if (key == '/')  // Si se presiona '/' - Mostrar �ltimo n�mero guardado
		{
			load_phone_from_eeprom();
			
			// Volver a la pantalla principal
			LCD_Command(0x01);        // Limpiar pantalla
			_delay_ms(2);
			LCD_String_xy(0,0,"Num telefono:");
			
			// Mantener el n�mero actual en pantalla si existe
			for(uint8_t i = 0; i < pos; i++)
			{
				LCD_Command(0xC0 + i);
				LCD_Char(phone_buffer[i]);
			}
		}
		else if (pos < MAX_PHONE_LENGTH) // Solo escribir si hay espacio
		{
			// Solo permitir d�gitos 0-9 (NO operaciones matem�ticas)
			if(key >= '0' && key <= '9')
			{
				LCD_Command(0xC0 + pos); // Mover cursor a l�nea 2, columna pos
				LCD_Char(key);           // Mostrar la tecla presionada
				phone_buffer[pos] = key; // Guardar en buffer
				pos++;                   // Avanzar posici�n
			}
			// Las teclas de operaciones matem�ticas (+, -, *, /) no hacen nada
		}
	}
}