/*
 * 3 Ultrasonic sensors HC-SR04 with ATmega16
 * Selecci�n por bot�n entre sensores
 */
#define F_CPU 8000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <string.h>
#include <stdlib.h>
#include "LCD_16x2_H_file.h"

// Definir pines para los 3 sensores
#define Trigger_pin1    PA0    /* Sensor 1 Trigger */
#define Trigger_pin2    PA1    /* Sensor 2 Trigger */
#define Trigger_pin3    PA2    /* Sensor 3 Trigger */

#define Echo_pin        PD6    /* Pin com�n de Echo (ICP1) */
#define Button_pin      PD7    /* Bot�n selector */

int TimerOverflow = 0;
volatile uint8_t current_sensor = 1;  /* Sensor activo (1, 2 o 3) */
volatile uint8_t button_pressed = 0;

ISR(TIMER1_OVF_vect)
{
    TimerOverflow++;
}

// Funci�n para leer el sensor ultras�nico
double read_ultrasonic(uint8_t trigger_pin)
{
    long count;
    double distance;
    
    // Dar pulso de trigger de 10us
    PORTA |= (1 << trigger_pin);
    _delay_us(10);
    PORTA &= (~(1 << trigger_pin));
    
    TCNT1 = 0;              /* Limpiar contador */
    TCCR1B = 0x41;          /* Captura en flanco ascendente */
    TIFR = 1<<ICF1;         /* Limpiar flag ICP */
    TIFR = 1<<TOV1;         /* Limpiar flag overflow */
    
    // Esperar flanco ascendente
    while ((TIFR & (1 << ICF1)) == 0);
    
    TCNT1 = 0;              /* Limpiar contador */
    TCCR1B = 0x01;          /* Captura en flanco descendente */
    TIFR = 1<<ICF1;         /* Limpiar flag ICP */
    TIFR = 1<<TOV1;         /* Limpiar flag overflow */
    TimerOverflow = 0;      /* Resetear contador overflow */
    
    // Esperar flanco descendente
    while ((TIFR & (1 << ICF1)) == 0);
    
    count = ICR1 + (65535 * TimerOverflow);
    distance = (double)count / 466.47;  /* Calcular distancia */
    
    return distance;
}

// Funci�n para detectar presi�n de bot�n
uint8_t button_pressed_check(void)
{
    static uint8_t button_state = 0;
    static uint8_t last_button_state = 1;
    
    button_state = (PIND & (1 << Button_pin)) ? 1 : 0;
    
    if (last_button_state == 1 && button_state == 0) {
        last_button_state = button_state;
        _delay_ms(50);  // Debounce
        return 1;
    }
    
    last_button_state = button_state;
    return 0;
}

int main(void)
{
    char string[15];
    char sensor_label[15];
    double distance;
    
    // Configurar pines
    DDRA = 0x07;            /* PA0, PA1, PA2 como salidas (triggers) */
    PORTD = 0xFF;           /* Activar pull-ups en PORTD */
    
    LCD_Init();
    LCD_String_xy(1, 0, "3 Ultrasonicos");
    _delay_ms(2000);
    LCD_Clear();
    
    sei();                  /* Habilitar interrupciones globales */
    TIMSK = (1 << TOIE1);   /* Habilitar overflow Timer1 */
    TCCR1A = 0;             /* Operaci�n normal */
    
    while(1)
    {
        // Verificar si se presion� el bot�n
        if (button_pressed_check()) {
            current_sensor++;
            if (current_sensor > 3) {
                current_sensor = 1;
            }
            LCD_Clear();
        }
        
        // Leer el sensor activo
        switch(current_sensor) {
            case 1:
                distance = read_ultrasonic(Trigger_pin1);
                strcpy(sensor_label, "Sensor 1:");
                break;
            case 2:
                distance = read_ultrasonic(Trigger_pin2);
                strcpy(sensor_label, "Sensor 2:");
                break;
            case 3:
                distance = read_ultrasonic(Trigger_pin3);
                strcpy(sensor_label, "Sensor 3:");
                break;
        }
        
        // Mostrar en LCD
        dtostrf(distance, 4, 1, string);
        strcat(string, " cm");
        
        LCD_String_xy(1, 0, sensor_label);
        LCD_String_xy(2, 0, "Dist: ");
        LCD_String_xy(2, 6, string);
        
        _delay_ms(300);
    }
}