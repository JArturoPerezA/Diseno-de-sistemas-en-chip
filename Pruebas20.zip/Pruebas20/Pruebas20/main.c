/**
 * main.c (Optimizado para ATmega16 - Memoria Reducida)
 * Sistema de control dual RFID con ATmega16 + 3 Sensores Ultras�nicos
 * 
 * RFID 2 ? Ultras�nico 1
 * RFID 3 ? Ultras�nico 2  
 * RFID 4 ? Ultras�nico 3
 */

#define F_CPU 8000000UL  // 8 MHz

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <string.h>
#include <stdlib.h>
#include "twi_lcd.h"
#include "mfrc522.h"
#include "eeprom_manager.h"
#include "keypad.h"
#include "lcd_utils.h"
#include "hc_sr04.h"

//Servo
#define SERVO_DDR DDRD
#define SERVO_PORT PORTD
#define SERVO_PIN PD5

// Definici�n del pin para LED
#define LED_PIN     PD7

// Constantes para los sensores
#define SENSOR_COUNT 4
#define SENSOR_ACCESS 0   // �ndice para el sensor de control de acceso (1)
#define SENSOR_DETECT1 1  // �ndice para el sensor de detecci�n (2)
#define SENSOR_DETECT2 2  // �ndice para el sensor de funciones adicionales (3)
#define SENSOR_DETECT3 3  // �ndice para el cuarto sensor (4)

// Estados para la medici�n ultras�nica (optimizado)
typedef enum {
    US_IDLE = 0,
    US_FIRST = 1,
    US_WAIT = 2,
    US_SECOND = 3,
    US_DISPLAY = 4
} us_state_t;

// Estructura optimizada para mediciones ultras�nicas
typedef struct {
    uint8_t active;           // Si est� activa la medici�n
    us_state_t state;         // Estado actual
    uint16_t start_time;      // Tiempo de inicio (en decisegundos para ahorrar memoria)
    int16_t dist1;            // Primera distancia medida
    int16_t dist2;            // Segunda distancia medida
    uint8_t us_id;            // ID del sensor ultras�nico asociado
    uint8_t disp_timer;       // Timer para mostrar resultado
} us_measurement_t;

// Estructura optimizada para sensores RFID
typedef struct {
    uint8_t id;               // ID del sensor (1-4)
    uint8_t busy;             // Bandera de sensor ocupado
    void (*process)();        // Funci�n para procesar la tarjeta detectada
} Sensor_t;

// Variables globales optimizadas
uint8_t displayTimer = 0;
Sensor_t sensors[SENSOR_COUNT];

// Mediciones ultras�nicas para cada RFID (2, 3, 4) - Optimizado
us_measurement_t us_meas[3] = {
    {0, US_IDLE, 0, -1, -1, 0, 0}, // RFID 2 ? US 1
    {0, US_IDLE, 0, -1, -1, 1, 0}, // RFID 3 ? US 2
    {0, US_IDLE, 0, -1, -1, 2, 0}  // RFID 4 ? US 3
};

// Variable optimizada para tiempo
volatile uint16_t sys_decisec = 0; // Decisegundos para ahorrar memoria

// Interrupci�n optimizada del Timer2 (decisegundos)
ISR(TIMER2_COMP_vect) {
    static uint8_t count = 0;
    count++;
    if (count >= 10) { // Cada 10 interrupciones = 1 decisegundo
        sys_decisec++;
        count = 0;
    }
}

// Funciones de LED optimizadas
void LED_Init(void) {
    DDRD |= (1<<LED_PIN);
    PORTD &= ~(1<<LED_PIN);
}

void LED_On(void) { PORTD |= (1<<LED_PIN); }
void LED_Off(void) { PORTD &= ~(1<<LED_PIN); }

// Timer optimizado para ATmega16
void init_timer(void) {
    TCCR2 = (1<<WGM21) | (1<<CS22) | (1<<CS20); // CTC, prescaler 128
    OCR2 = 62; // ~100Hz (10ms)
    TIMSK |= (1<<OCIE2);
}

uint16_t get_time(void) {
    uint16_t time;
    cli();
    time = sys_decisec;
    sei();
    return time;
}

void init_servo(void) {
    DDRD |= (1<<PD5);
    TCNT1 = 0;
    ICR1 = 19999;
    TCCR1A = (1<<WGM11) | (1<<COM1A1);
    TCCR1B = (1<<WGM12) | (1<<WGM13) | (1<<CS11);
}

// Funci�n optimizada para iniciar medici�n
void start_us_meas(uint8_t idx) {
    if (idx < 3) {
        us_meas[idx].active = 1;
        us_meas[idx].state = US_FIRST;
        us_meas[idx].start_time = get_time();
        us_meas[idx].dist1 = -1;
        us_meas[idx].dist2 = -1;
        us_meas[idx].disp_timer = 0;
    }
}

// Funci�n optimizada para procesar mediciones
void process_us_meas(void) {
    uint16_t curr_time = get_time();
    
    for (uint8_t i = 0; i < 3; i++) {
        if (!us_meas[i].active) continue;
        
        switch (us_meas[i].state) {
            case US_IDLE:
                // Estado inactivo, no hacer nada
                break;
                
            case US_FIRST:
                us_meas[i].dist1 = hc_sr04_get_distance(us_meas[i].us_id);
                if (us_meas[i].dist1 >= 0) {
                    us_meas[i].state = US_WAIT;
                }
                break;
                
            case US_WAIT:
                // Esperar 70 decisegundos = 7 segundos
                if ((curr_time - us_meas[i].start_time) >= 70) {
                    us_meas[i].state = US_SECOND;
                }
                break;
                
            case US_SECOND:
                us_meas[i].dist2 = hc_sr04_get_distance(us_meas[i].us_id);
                if (us_meas[i].dist2 >= 0) {
                    us_meas[i].state = US_DISPLAY;
                    us_meas[i].disp_timer = 50; // 5 segundos
                }
                break;
                
            case US_DISPLAY:
                if (us_meas[i].disp_timer > 0) {
                    // Mostrar en LCD de forma optimizada
                    char buf[6];
                    
                    twi_lcd_cmd(0x01);
                    twi_lcd_msg("RFID");
                    twi_lcd_dwr('0' + (i + 2));
                    twi_lcd_msg(" D1:");
                    itoa(us_meas[i].dist1, buf, 10);
                    twi_lcd_msg(buf);
                    
                    twi_lcd_cmd(0xC0);
                    twi_lcd_msg("D2:");
                    itoa(us_meas[i].dist2, buf, 10);
                    twi_lcd_msg(buf);
                    twi_lcd_msg("cm");
                    
                    us_meas[i].disp_timer--;
                    
                    if (us_meas[i].disp_timer == 0) {
                        us_meas[i].active = 0;
                        us_meas[i].state = US_IDLE;
                        displayTimer = 0;
                    }
                }
                break;
        }
    }
}

// Verificar si hay medici�n activa
uint8_t is_us_active(void) {
    for (uint8_t i = 0; i < 3; i++) {
        if (us_meas[i].active) return 1;
    }
    return 0;
}

// Procesamiento optimizado para sensores
void processAccess() {
    displayUID_LCD(1);
    _delay_ms(1500);
    
    uint8_t access = checkUID_Authorization();
    displayAccessResult(access);
    
    if (!access) {
        twi_lcd_cmd(0x01);
        twi_lcd_msg("Agregando...");
        _delay_ms(2000);
        
        if (addUID_ToEEPROM(getCardUID(1)->uidByte)) {
            keypad_get_input();
            twi_lcd_cmd(0x01);
            twi_lcd_msg("UID Agregada!");
        } else {
            twi_lcd_cmd(0x01);
            twi_lcd_msg("Memoria llena!");
        }
        _delay_ms(2000);
        displayAuthorizedCount();
        _delay_ms(2000);
    }
    displayTimer = 50;
}

void processDetect1() {
    LED_On();
    _delay_ms(500);
    LED_Off();
    start_us_meas(0); // RFID 2 ? US 1
    
    if (!is_us_active() || displayTimer == 0) {
        twi_lcd_cmd(0x01);
        twi_lcd_msg("RFID2: Midiendo");
        displayTimer = 20;
    }
}

void processDetect2() {
    LED_On();
    _delay_ms(500);
    LED_Off();
    start_us_meas(1); // RFID 3 ? US 2
    
    if (!is_us_active() || displayTimer == 0) {
        twi_lcd_cmd(0x01);
        twi_lcd_msg("RFID3: Midiendo");
        displayTimer = 20;
    }
}

void processDetect3() {
    LED_On();
    _delay_ms(500);
    LED_Off();
    start_us_meas(2); // RFID 4 ? US 3
    
    if (!is_us_active() || displayTimer == 0) {
        twi_lcd_cmd(0x01);
        twi_lcd_msg("RFID4: Midiendo");
        displayTimer = 20;
    }
}

// Test optimizado
void testSensor(uint8_t num) {
    uint8_t ver = MFRC522_ReadRegister(VersionReg, num);
    char buf[3];
    
    twi_lcd_cmd(0x01);
    twi_lcd_msg("Test Sensor ");
    twi_lcd_dwr('0' + num);
    twi_lcd_msg(":");
    
    twi_lcd_cmd(0xC0);
    
    if (ver == 0x91 || ver == 0x92) {
        twi_lcd_msg("OK-Ver:");
        byteToHex(ver, buf);
        twi_lcd_msg(buf);
    } else {
        twi_lcd_msg("Error conexion");
    }
    _delay_ms(2000);
}

// Inicializaci�n optimizada
void initSensors() {
    sensors[0].id = 1; sensors[0].busy = 0; sensors[0].process = processAccess;
    sensors[1].id = 2; sensors[1].busy = 0; sensors[1].process = processDetect1;
    sensors[2].id = 3; sensors[2].busy = 0; sensors[2].process = processDetect2;
    sensors[3].id = 4; sensors[3].busy = 0; sensors[3].process = processDetect3;
}

// Manejo optimizado de RFID
void handleRFID() {
    // Sensor 1 tiene prioridad
    if (MFRC522_IsNewCardPresent(1)) {
        if (MFRC522_ReadCardSerial(1)) {
            sensors[0].busy = 1;
            sensors[0].process();
            _delay_ms(500);
            sensors[0].busy = 0;
            return;
        }
    }
    
    // Otros sensores
    if (!sensors[0].busy) {
        for (uint8_t i = 1; i < SENSOR_COUNT; i++) {
            if (MFRC522_IsNewCardPresent(sensors[i].id)) {
                if (MFRC522_ReadCardSerial(sensors[i].id)) {
                    sensors[i].process();
                    _delay_ms(500);
                    return;
                }
            }
        }
    }
}

// Display optimizado
void updateDisplay() {
    if (is_us_active()) return;
    
    if (displayTimer > 0) {
        displayTimer--;
        if (displayTimer == 0) {
            twi_lcd_cmd(0x01);
            twi_lcd_msg("S1:Acc S2:US1");
            twi_lcd_cmd(0xC0);
            twi_lcd_msg("S3:US2 S4:US3");
        }
    }
}

int main(void) {
    // Inicializaci�n b�sica
    twi_init();
    twi_lcd_init();
    SPI_Init();
    LED_Init();
    DDRA = 0x0F;
    PORTA = 0xF0;
    keypad_init();
    init_timer();
    
    // Inicializar ultras�nicos
    hc_sr04_init_all();
    
    // Inicializar RFID
    MFRC522_Init(1);
    MFRC522_Init(2);
    MFRC522_Init(3);
    MFRC522_Init(4);
    
    init_servo();
    initializeEEPROM();
    initSensors();
    
    sei(); // Habilitar interrupciones
    
    // Mensaje inicial
    twi_lcd_cmd(0x01);
    twi_lcd_msg("Sistema RFID+US");
    _delay_ms(2000);
    
    // Test b�sico
    for (uint8_t i = 1; i <= 4; i++) {
        testSensor(i);
    }
    
    // Test ultras�nicos b�sico
    twi_lcd_cmd(0x01);
    twi_lcd_msg("Test US...");
    _delay_ms(1000);
    
    displayAuthorizedCount();
    _delay_ms(2000);
    
    // Iniciar ultras�nicos en segundo plano
    hc_sr04_start_continuous_measurement();
    
    // Mensaje normal
    twi_lcd_cmd(0x01);
    twi_lcd_msg("S1:Acc S2:US1");
    twi_lcd_cmd(0xC0);
    twi_lcd_msg("S3:US2 S4:US3");
    
    // Bucle principal optimizado
    while(1) {
        // Procesar ultras�nicos
        hc_sr04_process_measurements();
        hc_sr04_process_sensor3_polling();
        
        // Procesar mediciones por RFID
        process_us_meas();
        
        // Manejar RFID
        handleRFID();
        
        // Actualizar display
        updateDisplay();
        
        _delay_ms(50);
    }
    
    return 0;
}