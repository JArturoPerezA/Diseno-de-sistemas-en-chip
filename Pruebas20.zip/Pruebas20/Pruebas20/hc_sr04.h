/**
 * HC-SR04 Ultrasonic Sensor Library - Multi Sensor Version
 * Header file for 3 HC-SR04 sensors with TWI LCD display
 * Sensor 1 y 2: Interrupciones, Sensor 3: Polling
 */
#ifndef HC_SR04_H
#define HC_SR04_H

#include <avr/io.h>
#include <stdint.h>

// N�mero de sensores
#define NUM_SENSORS 3

// Configuraci�n de pines para los 3 sensores
// Sensor 1 (original) - Interrupci�n INT1
#define TRIGGER1_PORT    PORTD
#define TRIGGER1_DDR     DDRD
#define TRIGGER1_PIN     PIND4
#define ECHO1_PORT       PORTD
#define ECHO1_DDR        DDRD
#define ECHO1_PIN        PIND3
#define ECHO1_PIN_REG    PIND    // Registro de lectura del pin

// Sensor 2 - Interrupci�n INT0
#define TRIGGER2_PORT    PORTD
#define TRIGGER2_DDR     DDRD
#define TRIGGER2_PIN     PIND6
#define ECHO2_PORT       PORTD
#define ECHO2_DDR        DDRD
#define ECHO2_PIN        PIND2
#define ECHO2_PIN_REG    PIND    // Registro de lectura del pin

// Sensor 3 - Polling (sin interrupci�n)
#define TRIGGER3_PORT    PORTD
#define TRIGGER3_DDR     DDRD
#define TRIGGER3_PIN     PIND0
#define ECHO3_PORT       PORTD
#define ECHO3_DDR        DDRD
#define ECHO3_PIN        PIND1
#define ECHO3_PIN_REG    PIND    // Registro de lectura del pin para polling

// Configuraci�n del sensor
#define MAX_DISTANCE_CM     400     // Distancia m�xima en cm
#define TIMEOUT_COUNTS      91      // Valor de timeout para el timer
#define DISTANCE_FACTOR     58      // Factor de conversi�n para distancia

// Estados del sensor
typedef enum {
    SENSOR_IDLE = 0,
    SENSOR_MEASURING,
    SENSOR_DATA_READY,
    SENSOR_ERROR
} sensor_state_t;

// Estructura de datos del sensor (individual)
typedef struct {
    int distance_cm;            // Distancia medida en cm
    uint8_t error;              // Flag de error
    uint8_t measuring;          // Flag de medici�n en curso
    uint16_t timer_value;       // Valor del timer para c�lculos
    uint8_t rising_edge;        // Flag de flanco de subida
    sensor_state_t state;       // Estado actual del sensor
    uint32_t last_measurement;  // Timestamp de �ltima medici�n
} hc_sr04_data_t;

// Array de sensores
extern volatile hc_sr04_data_t sensors_data[NUM_SENSORS];
extern volatile uint8_t current_sensor;  // Sensor actualmente siendo medido

// Funciones p�blicas del sensor
void hc_sr04_init_all(void);
void hc_sr04_trigger_measurement(uint8_t sensor_id);
void hc_sr04_trigger_all_sequential(void);
sensor_state_t hc_sr04_get_state(uint8_t sensor_id);
int hc_sr04_get_distance(uint8_t sensor_id);
uint8_t hc_sr04_has_error(uint8_t sensor_id);
void hc_sr04_clear_error(uint8_t sensor_id);
uint8_t hc_sr04_is_measuring(uint8_t sensor_id);
void hc_sr04_clear_all_errors(void);

// Funciones de display (modificadas para m�ltiples sensores)
void hc_sr04_display_init(void);
void hc_sr04_display_update_all(void);
void hc_sr04_display_update_sensor(uint8_t sensor_id);
void hc_sr04_display_clear(void);
void hc_sr04_display_message(const char* message);

// Funciones de utilidad
void hc_sr04_delay_ms(uint16_t ms);
void hc_sr04_test_all_sensors(uint8_t num_tests);
uint32_t hc_sr04_get_millis(void);  // Simple contador de tiempo

// Funciones para manejo secuencial autom�tico
void hc_sr04_start_continuous_measurement(void);
void hc_sr04_stop_continuous_measurement(void);
void hc_sr04_process_measurements(void);

// Funci�n espec�fica para polling del sensor 3
void hc_sr04_process_sensor3_polling(void);

#endif // HC_SR04_H
