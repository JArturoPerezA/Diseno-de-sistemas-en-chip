/**
 * keypad.h - Optimizado para ATmega16
 * Interfaz para el manejo de teclado matricial 4x4 usando PORTA
 */
#ifndef KEYPAD_H
#define KEYPAD_H

#include <avr/io.h>

#ifndef F_CPU
#define F_CPU 8000000UL  // Solo definir si no est� ya definido
#endif

#include <util/delay.h>

// Definiciones para el teclado
#define KEYPAD_PORT     PORTA    // Puerto para el teclado
#define KEYPAD_DDR      DDRA     // Registro de direcci�n de datos
#define KEYPAD_PIN      PINA     // Registro para leer el puerto
#define KEYPAD_ROWS     0x0F     // PA0-PA3: Filas (salidas)
#define KEYPAD_COLS     0xF0     // PA4-PA7: Columnas (entradas)

// Variables globales optimizadas para datos del usuario
extern char user_type;          // 'A' o 'B'
extern char user_number[9];     // Reducido de 17 a 9 bytes

// Funciones adicionales
char keypad_get_user_type(void);
char* keypad_get_user_number(void);

// Inicializar el teclado
void keypad_init(void);

// Escanear el teclado y retornar la tecla presionada
// Retorna: 0-15 para las teclas, 0xFF si no hay tecla
uint8_t keypad_scan(void);

// Convierte el c�digo de escaneo a car�cter
char keypad_map_to_char(uint8_t key_code);

// Obtener entrada del teclado y mostrarla en LCD hasta que se presione #
void keypad_get_input(void);

// Funci�n de debug optimizada
void keypad_debug_scan(void);

#endif /* KEYPAD_H */