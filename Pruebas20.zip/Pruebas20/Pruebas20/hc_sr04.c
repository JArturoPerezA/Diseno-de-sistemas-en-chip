/**
 * HC-SR04 Ultrasonic Sensor Library - Multi Sensor Version
 * Implementation file for 3 HC-SR04 sensors with TWI LCD display
 * Sensor 1 y 2: Interrupciones, Sensor 3: Polling
 */

#define F_CPU 8000000UL  // 8 MHz

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdlib.h>
#include <string.h>
#include "hc_sr04.h"
#include "twi_lcd.h"

// Array de sensores
volatile hc_sr04_data_t sensors_data[NUM_SENSORS];
volatile uint8_t current_sensor = 0;
volatile uint8_t continuous_mode = 0;
volatile uint32_t millis_counter = 0;

// Variables para optimizaci�n del display
static int last_distances[NUM_SENSORS] = {-1, -1, -1};
static uint8_t last_errors[NUM_SENSORS] = {2, 2, 2};

// Configuraci�n de pines por sensor
typedef struct {
    volatile uint8_t* trigger_port;
    volatile uint8_t* trigger_ddr;
    uint8_t trigger_pin;
    volatile uint8_t* echo_port;
    volatile uint8_t* echo_ddr;
    volatile uint8_t* echo_pin_reg;  // Para leer el pin
    uint8_t echo_pin;
    uint8_t int_mask;  // M�scara de interrupci�n
} sensor_pins_t;

// Configuraci�n de pines para cada sensor
static const sensor_pins_t sensor_pins[NUM_SENSORS] = {
    {&TRIGGER1_PORT, &TRIGGER1_DDR, TRIGGER1_PIN, &ECHO1_PORT, &ECHO1_DDR, &ECHO1_PIN_REG, ECHO1_PIN, (1 << INT1)},
    {&TRIGGER2_PORT, &TRIGGER2_DDR, TRIGGER2_PIN, &ECHO2_PORT, &ECHO2_DDR, &ECHO2_PIN_REG, ECHO2_PIN, (1 << INT0)},
    {&TRIGGER3_PORT, &TRIGGER3_DDR, TRIGGER3_PIN, &ECHO3_PORT, &ECHO3_DDR, &ECHO3_PIN_REG, ECHO3_PIN, 0}  // Sin interrupci�n
};

// === INTERRUPCIONES ===

// Interrupci�n por overflow del Timer0 (para timeout)
ISR (TIMER0_OVF_vect) {
    millis_counter++;  // Contador de tiempo simple
    
    // Verificar timeout para sensores con interrupciones (1 y 2)
    if(current_sensor < 2 && sensors_data[current_sensor].measuring && sensors_data[current_sensor].rising_edge) {
        sensors_data[current_sensor].timer_value++;
        if(sensors_data[current_sensor].timer_value > TIMEOUT_COUNTS) {
            sensors_data[current_sensor].measuring = 0;
            sensors_data[current_sensor].rising_edge = 0;
            sensors_data[current_sensor].error = 1;
            sensors_data[current_sensor].state = SENSOR_ERROR;
        }
    }
}

// Interrupci�n externa INT0 (Sensor 2)
ISR (INT0_vect) {
    if(current_sensor == 1 && sensors_data[1].measuring) {
        if(sensors_data[1].rising_edge == 0) {
            sensors_data[1].rising_edge = 1;
            TCNT0 = 0;
            sensors_data[1].timer_value = 0;
        } else {
            sensors_data[1].rising_edge = 0;
            sensors_data[1].distance_cm = (sensors_data[1].timer_value * 256 + TCNT0) / DISTANCE_FACTOR;
            sensors_data[1].measuring = 0;
            sensors_data[1].state = SENSOR_DATA_READY;
            sensors_data[1].last_measurement = millis_counter;
        }
    }
}

// Interrupci�n externa INT1 (Sensor 1)
ISR (INT1_vect) {
    if(current_sensor == 0 && sensors_data[0].measuring) {
        if(sensors_data[0].rising_edge == 0) {
            sensors_data[0].rising_edge = 1;
            TCNT0 = 0;
            sensors_data[0].timer_value = 0;
        } else {
            sensors_data[0].rising_edge = 0;
            sensors_data[0].distance_cm = (sensors_data[0].timer_value * 256 + TCNT0) / DISTANCE_FACTOR;
            sensors_data[0].measuring = 0;
            sensors_data[0].state = SENSOR_DATA_READY;
            sensors_data[0].last_measurement = millis_counter;
        }
    }
}

// === FUNCIONES PRIVADAS ===

static void initialize_external_interrupts(void) {
    // Configurar INT0 (PD2) - cualquier cambio l�gico
    MCUCR |= (1 << ISC00);
    GICR |= (1 << INT0);
    
    // Configurar INT1 (PD3) - cualquier cambio l�gico
    MCUCR |= (1 << ISC10);
    GICR |= (1 << INT1);
    
    // INT2 ya no se configura - sensor 3 usar� polling
}

static void initialize_timer0(void) {
    TCCR0 |= (1 << CS00);   // Sin prescaler
    TCNT0 = 0;              // Reset timer
    TIMSK |= (1 << TOIE0);  // Habilitar interrupci�n por overflow
}

static void configure_all_pins(void) {
    // Configurar pines para todos los sensores
    for(uint8_t i = 0; i < NUM_SENSORS; i++) {
        *sensor_pins[i].trigger_ddr |= (1 << sensor_pins[i].trigger_pin);  // Trigger como salida
        *sensor_pins[i].echo_ddr &= ~(1 << sensor_pins[i].echo_pin);       // Echo como entrada
    }
}

static void send_trigger_pulse(uint8_t sensor_id) {
    if(sensor_id >= NUM_SENSORS) return;
    
    const sensor_pins_t* pins = &sensor_pins[sensor_id];
    
    *pins->trigger_port &= ~(1 << pins->trigger_pin);  // Trigger bajo
    _delay_us(2);
    *pins->trigger_port |= (1 << pins->trigger_pin);   // Pulso de 10us
    _delay_us(10);
    *pins->trigger_port &= ~(1 << pins->trigger_pin);  // Trigger bajo
}

// Funci�n para medir sensor 3 por polling
static void measure_sensor3_polling(void) {
    if(sensors_data[2].measuring) {
        uint8_t echo_state = (*sensor_pins[2].echo_pin_reg & (1 << sensor_pins[2].echo_pin)) ? 1 : 0;
        
        if(!sensors_data[2].rising_edge && echo_state) {
            // Flanco de subida detectado
            sensors_data[2].rising_edge = 1;
            TCNT0 = 0;
            sensors_data[2].timer_value = 0;
        } else if(sensors_data[2].rising_edge && !echo_state) {
            // Flanco de bajada detectado
            sensors_data[2].rising_edge = 0;
            sensors_data[2].distance_cm = (sensors_data[2].timer_value * 256 + TCNT0) / DISTANCE_FACTOR;
            sensors_data[2].measuring = 0;
            sensors_data[2].state = SENSOR_DATA_READY;
            sensors_data[2].last_measurement = millis_counter;
        } else if(sensors_data[2].rising_edge) {
            // Contar tiempo mientras esperamos flanco de bajada
            static uint8_t last_tcnt0 = 0;
            if(TCNT0 < last_tcnt0) {
                // Overflow detectado
                sensors_data[2].timer_value++;
                if(sensors_data[2].timer_value > TIMEOUT_COUNTS) {
                    // Timeout
                    sensors_data[2].measuring = 0;
                    sensors_data[2].rising_edge = 0;
                    sensors_data[2].error = 1;
                    sensors_data[2].state = SENSOR_ERROR;
                }
            }
            last_tcnt0 = TCNT0;
        }
    }
}

// === FUNCIONES P�BLICAS ===

void hc_sr04_init_all(void) {
    // Inicializar todos los sensores
    for(uint8_t i = 0; i < NUM_SENSORS; i++) {
        sensors_data[i].distance_cm = 0;
        sensors_data[i].error = 0;
        sensors_data[i].measuring = 0;
        sensors_data[i].timer_value = 0;
        sensors_data[i].rising_edge = 0;
        sensors_data[i].state = SENSOR_IDLE;
        sensors_data[i].last_measurement = 0;
    }
    
    current_sensor = 0;
    continuous_mode = 0;
    millis_counter = 0;
    
    // Configurar hardware
    configure_all_pins();
    initialize_external_interrupts();
    initialize_timer0();
    
    // Habilitar interrupciones globales
    sei();
}

void hc_sr04_trigger_measurement(uint8_t sensor_id) {
    if(sensor_id >= NUM_SENSORS) return;
    
    if(sensors_data[sensor_id].measuring == 0 && sensors_data[sensor_id].state != SENSOR_MEASURING) {
        current_sensor = sensor_id;
        _delay_ms(10); // Pausa peque�a entre mediciones
        send_trigger_pulse(sensor_id);
        sensors_data[sensor_id].measuring = 1;
        sensors_data[sensor_id].error = 0;
        sensors_data[sensor_id].state = SENSOR_MEASURING;
    }
}

void hc_sr04_trigger_all_sequential(void) {
    for(uint8_t i = 0; i < NUM_SENSORS; i++) {
        hc_sr04_trigger_measurement(i);
        
        // Esperar a que termine la medici�n
        uint16_t timeout = 0;
        while(sensors_data[i].measuring && timeout < 1000) {
            if(i == 2) {
                // Para sensor 3, procesar polling
                measure_sensor3_polling();
            }
            _delay_ms(1);
            timeout++;
        }
        
        _delay_ms(30); // Pausa entre sensores
    }
}

sensor_state_t hc_sr04_get_state(uint8_t sensor_id) {
    if(sensor_id >= NUM_SENSORS) return SENSOR_ERROR;
    return sensors_data[sensor_id].state;
}

int hc_sr04_get_distance(uint8_t sensor_id) {
    if(sensor_id >= NUM_SENSORS) return -1;
    
    if(sensors_data[sensor_id].state == SENSOR_DATA_READY && !sensors_data[sensor_id].error) {
        sensors_data[sensor_id].state = SENSOR_IDLE;  // Marcar como le�do
        return sensors_data[sensor_id].distance_cm;
    }
    return -1;  // Error o sin datos
}

uint8_t hc_sr04_has_error(uint8_t sensor_id) {
    if(sensor_id >= NUM_SENSORS) return 1;
    return sensors_data[sensor_id].error;
}

void hc_sr04_clear_error(uint8_t sensor_id) {
    if(sensor_id >= NUM_SENSORS) return;
    sensors_data[sensor_id].error = 0;
    sensors_data[sensor_id].state = SENSOR_IDLE;
}

void hc_sr04_clear_all_errors(void) {
    for(uint8_t i = 0; i < NUM_SENSORS; i++) {
        hc_sr04_clear_error(i);
    }
}

uint8_t hc_sr04_is_measuring(uint8_t sensor_id) {
    if(sensor_id >= NUM_SENSORS) return 0;
    return sensors_data[sensor_id].measuring;
}

// === FUNCIONES DE DISPLAY ===

void hc_sr04_display_init(void) {
    twi_init();
    twi_lcd_init();
    
    twi_lcd_cmd(0x01);  // Clear display
    twi_lcd_msg("3 Sensores HC-SR04");
    _delay_ms(2000);
    
    twi_lcd_cmd(0x01);
    
    // Reset variables de display
    for(uint8_t i = 0; i < NUM_SENSORS; i++) {
        last_distances[i] = -1;
        last_errors[i] = 2;
    }
}

void hc_sr04_display_update_all(void) {
    char line1[17] = "S1:--- S2:--- S3";
    char line2[17] = ":---            ";
    char value[4];
    
    // Actualizar datos de cada sensor
    for(uint8_t i = 0; i < NUM_SENSORS; i++) {
        uint8_t pos = (i == 0) ? 3 : (i == 1) ? 10 : 2; // Posiciones en las l�neas
        uint8_t line = (i < 2) ? 1 : 2;
        
        if(sensors_data[i].error) {
            if(line == 1) {
                line1[pos] = '-'; line1[pos+1] = '-'; line1[pos+2] = '-';
            } else {
                line2[pos] = '-'; line2[pos+1] = '-'; line2[pos+2] = '-';
            }
        } else {
            itoa(sensors_data[i].distance_cm, value, 10);
            uint8_t len = strlen(value);
            
            if(line == 1) {
                for(uint8_t j = 0; j < 3; j++) {
                    line1[pos + j] = (j < len) ? value[j] : ' ';
                }
            } else {
                for(uint8_t j = 0; j < 3; j++) {
                    line2[pos + j] = (j < len) ? value[j] : ' ';
                }
            }
        }
    }
    
    // Mostrar en LCD
    twi_lcd_cmd(0x80);  // Primera l�nea
    twi_lcd_msg(line1);
    twi_lcd_cmd(0xC0);  // Segunda l�nea
    twi_lcd_msg(line2);
}

void hc_sr04_display_update_sensor(uint8_t sensor_id) {
    if(sensor_id >= NUM_SENSORS) return;
    
    char message[17];
    char value[6];
    
    twi_lcd_cmd(0x01);  // Clear
    
    sprintf(message, "Sensor %d:", sensor_id + 1);
    twi_lcd_msg(message);
    
    twi_lcd_cmd(0xC0);  // Segunda l�nea
    
    if(sensors_data[sensor_id].error) {
        twi_lcd_msg("Error");
    } else {
        itoa(sensors_data[sensor_id].distance_cm, value, 10);
        twi_lcd_msg(value);
        twi_lcd_msg(" cm");
    }
}

void hc_sr04_display_clear(void) {
    twi_lcd_cmd(0x01);
    for(uint8_t i = 0; i < NUM_SENSORS; i++) {
        last_distances[i] = -1;
        last_errors[i] = 2;
    }
}

void hc_sr04_display_message(const char* message) {
    twi_lcd_cmd(0x01);
    twi_lcd_msg(message);
}

// === FUNCIONES DE UTILIDAD ===

void hc_sr04_delay_ms(uint16_t ms) {
    while(ms--) {
        _delay_ms(1);
    }
}

uint32_t hc_sr04_get_millis(void) {
    return millis_counter;
}

void hc_sr04_test_all_sensors(uint8_t num_tests) {
    hc_sr04_display_clear();
    twi_lcd_msg("Test 3 Sensores");
    _delay_ms(2000);
    
    for(uint8_t test = 0; test < num_tests; test++) {
        for(uint8_t sensor = 0; sensor < NUM_SENSORS; sensor++) {
            hc_sr04_trigger_measurement(sensor);
            
            // Esperar resultado
            uint16_t timeout = 0;
            while(hc_sr04_get_state(sensor) == SENSOR_MEASURING && timeout < 500) {
                if(sensor == 2) {
                    // Para sensor 3, procesar polling
                    measure_sensor3_polling();
                }
                _delay_ms(1);
                timeout++;
            }
            
            hc_sr04_display_update_sensor(sensor);
            _delay_ms(1000);
        }
    }
    
    hc_sr04_display_clear();
    twi_lcd_msg("Test completado");
    _delay_ms(2000);
}

// === FUNCIONES PARA MEDICI�N CONTINUA ===

void hc_sr04_start_continuous_measurement(void) {
    continuous_mode = 1;
}

void hc_sr04_stop_continuous_measurement(void) {
    continuous_mode = 0;
}

void hc_sr04_process_measurements(void) {
    static uint8_t sensor_index = 0;
    static uint32_t last_trigger_time = 0;
    
    if(!continuous_mode) return;
    
    uint32_t current_time = hc_sr04_get_millis();
    
    // Procesar polling del sensor 3 si est� midiendo
    if(sensors_data[2].measuring) {
        measure_sensor3_polling();
    }
    
    // Verificar si es tiempo de una nueva medici�n
    if(current_time - last_trigger_time > 100) {  // 100ms entre mediciones
        
        // Si el sensor actual no est� midiendo, iniciar medici�n del siguiente
        if(!sensors_data[sensor_index].measuring) {
            hc_sr04_trigger_measurement(sensor_index);
            sensor_index = (sensor_index + 1) % NUM_SENSORS;
            last_trigger_time = current_time;
        }
    }
}

// Funci�n adicional para procesar polling del sensor 3
void hc_sr04_process_sensor3_polling(void) {
    if(sensors_data[2].measuring) {
        measure_sensor3_polling();
    }
}