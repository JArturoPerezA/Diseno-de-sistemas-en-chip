/**
 * eeprom_manager.h - Optimizado para ATmega16
 * Funciones para gesti�n de UIDs en EEPROM
 */
#ifndef EEPROM_MANAGER_H
#define EEPROM_MANAGER_H

#include <avr/io.h>

// Configuraci�n optimizada para m�ltiples UIDs (para sensor 1)
#define EEPROM_START_ADDRESS    0x10    // Direcci�n inicial en EEPROM
#define MAX_AUTHORIZED_UIDS     15      // Reducido de 20 a 15 para ahorrar memoria
#define UID_SIZE                4       // Tama�o de cada UID en bytes
#define EEPROM_BLOCK_SIZE       8       // 4 bytes UID + 4 bytes de separaci�n/control

// Prototipos de funciones EEPROM
void EEPROM_write(unsigned int uiAddress, unsigned char ucData);
unsigned char EEPROM_read(unsigned int uiAddress);
void initializeEEPROM(void);
uint8_t isValidUID(uint8_t* uid);
uint8_t getNextFreeSlot(void);
uint8_t addUID_ToEEPROM(uint8_t* uid);
uint8_t checkUID_Authorization(void);
uint8_t clearAllUIDs(void);
void displayAuthorizedCount(void);

#endif /* EEPROM_MANAGER_H */