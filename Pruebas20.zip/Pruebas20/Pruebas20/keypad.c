/**
 * keypad.c - Optimizado para ATmega16
 * Implementaci�n del manejo de teclado matricial 4x4 usando PORTA
 * Optimizado para uso m�nimo de RAM
 */

#ifndef F_CPU
#define F_CPU 8000000UL  // Solo definir si no est� ya definido
#endif

#include "keypad.h"
#include "twi_lcd.h"
#include <util/delay.h>
#include <string.h>
#include <stdlib.h>

void keypad_init(void) {
    // Configurar PA0-PA3 como salidas (filas) y PA4-PA7 como entradas (columnas)
    KEYPAD_DDR |= KEYPAD_ROWS;    // PA0-PA3 como salidas
    KEYPAD_DDR &= ~KEYPAD_COLS;   // PA4-PA7 como entradas
    
    // Habilitar resistencias pull-up en los pines de columnas (entradas)
    KEYPAD_PORT |= KEYPAD_COLS;
    
    // Inicialmente, todas las filas est�n en alto (inactivas)
    KEYPAD_PORT |= KEYPAD_ROWS;
}

uint8_t keypad_scan(void) {
    int cont_filas = 4;
    char codigo_barrido = 0b11111110;  // Comenzamos con la primera fila en bajo
    int valor_tecla = 3;  // Valor inicial corregido para mapeo correcto
    int temp;
    
    while (cont_filas != 0) {
        // Aplicar patr�n de escaneo manteniendo pull-ups en columnas
        KEYPAD_PORT = (KEYPAD_PORT & KEYPAD_COLS) | (codigo_barrido & KEYPAD_ROWS);
        
        // Peque�a pausa para estabilizar la se�al
        _delay_us(10);
        
        // Leer estado de columnas
        temp = KEYPAD_PIN & KEYPAD_COLS;
        
        if (temp == KEYPAD_COLS) {  // Ninguna tecla presionada (todas columnas en alto)
            codigo_barrido = (codigo_barrido << 1) | 1;
            valor_tecla = valor_tecla + 4;
            cont_filas--;
            
            if (cont_filas == 0) {
                valor_tecla = 0xFF;  // No hay tecla presionada
                break;
            }
        } else {
            // Debounce m�s robusto
            _delay_ms(20);
            temp = KEYPAD_PIN & KEYPAD_COLS;
            
            if (temp == KEYPAD_COLS) {
                valor_tecla = 0xFF;  // Detecci�n espuria
                break;
            } else if (temp == 0b01110000) {
                // No cambiar valor_tecla (primera columna)
            } else if (temp == 0b10110000) {
                valor_tecla = valor_tecla - 1;  // Segunda columna
            } else if (temp == 0b11010000) {
                valor_tecla = valor_tecla - 2;  // Tercera columna
            } else if (temp == 0b11100000) {
                valor_tecla = valor_tecla - 3;  // Cuarta columna
            } else {
                // Manejar casos donde m�ltiples columnas est�n activas
                valor_tecla = 0xFF;  // Detecci�n inv�lida
                break;
            }
            
            // Esperar a que se suelte la tecla
            while ((KEYPAD_PIN & KEYPAD_COLS) != KEYPAD_COLS) {
                _delay_ms(1);
            }
            
            _delay_ms(20);  // Debounce despu�s de soltar
            cont_filas = 0;
        }
    }
    
    // Restaurar estado de filas (todas en alto)
    KEYPAD_PORT |= KEYPAD_ROWS;
    
    return valor_tecla;
}

// Mapear c�digos de escaneo a caracteres
char keypad_map_to_char(uint8_t key_code) {
    // Mapeo corregido - las columnas est�n f�sicamente invertidas
    switch (key_code) {
        case 0:  return '1';  case 1:  return '2';  case 2:  return '3';  case 3:  return 'A';
        case 4:  return '4';  case 5:  return '5';  case 6:  return '6';  case 7:  return 'B';
        case 8:  return '7';  case 9:  return '8';  case 10: return '9';  case 11: return 'C';
        case 12: return '*';  case 13: return '0';  case 14: return '#';  case 15: return 'D';
        default: return 0;    // Car�cter nulo para c�digos inv�lidos
    }
}

// Variables globales optimizadas para almacenar los datos
char user_type = 0;          // 'A' para estudiante, 'B' para colaborador
char user_number[9] = {0};   // Reducido de 17 a 9 (suficiente para matr�cula/n�mina)

// Funci�n optimizada para obtener tipo de usuario y n�mero
void keypad_get_input(void) {
    uint8_t key;
    char key_char;
    char input_buf[9] = {0};  // Buffer reducido - CORREGIDO: Declaraci�n movida aqu�
    uint8_t input_pos = 0;
    
    // PASO 1: Preguntar tipo de usuario
    twi_lcd_cmd(0x01);  // Limpiar pantalla
    _delay_ms(2);
    
    twi_lcd_msg("Seleccione usuario:");
    twi_lcd_cmd(0x94);  // L�nea 2
    twi_lcd_msg("A = Estudiante");
    twi_lcd_cmd(0xD4);  // L�nea 3
    twi_lcd_msg("B = Colaborador");
    
    // Esperar a que presione A o B
    while (1) {
        key = keypad_scan();
        
        if (key != 0xFF) {
            key_char = keypad_map_to_char(key);
            
            if (key_char == 'A') {
                user_type = 'A';
                break;
            } else if (key_char == 'B') {
                user_type = 'B';
                break;
            }
        }
        _delay_ms(50);
    }
    
    // PASO 2: Mostrar mensaje seg�n el tipo de usuario
    twi_lcd_cmd(0x01);
    _delay_ms(2);
    
    if (user_type == 'A') {
        twi_lcd_msg("Ingrese matricula:");
    } else {
        twi_lcd_msg("Ingrese nomina:");
    }
    
    twi_lcd_cmd(0x94);  // L�nea 2
    twi_lcd_msg("Debe iniciar con 0");
    twi_lcd_cmd(0x14);  // L�nea 4
    twi_lcd_msg("*=Borrar  #=Aceptar");
    
    _delay_ms(2000);
    
    // Preparar pantalla para captura
    twi_lcd_cmd(0x01);
    _delay_ms(2);
    
    if (user_type == 'A') {
        twi_lcd_msg("Matricula: ");
    } else {
        twi_lcd_msg("Nomina: ");
    }
    
    // PASO 3: Capturar el n�mero (optimizado)
    input_pos = 0;
    // Limpiar buffer manualmente en lugar de memset
    for (uint8_t i = 0; i < 9; i++) {
        input_buf[i] = 0;
    }
    uint8_t first_digit_entered = 0;
    
    while (1) {
        key = keypad_scan();
        
        if (key != 0xFF) {
            key_char = keypad_map_to_char(key);
            
            if (key_char == 0) {
                continue;  // Ignorar caracteres inv�lidos
            }
            
            // Si se presion� #, guardar y salir
            if (key_char == '#') {
                if (input_pos > 0) {
                    // Copiar al buffer global (optimizado)
                    for (uint8_t i = 0; i < input_pos && i < 8; i++) {
                        user_number[i] = input_buf[i];
                    }
                    user_number[input_pos] = '\0';
                    break;
                } else {
                    // Error si no hay entrada
                    twi_lcd_cmd(0xD4);  // L�nea 3
                    twi_lcd_msg("Ingrese un numero");
                    _delay_ms(1500);
                    twi_lcd_cmd(0xD4);
                    twi_lcd_msg("                ");
                    continue;
                }
            }
            
            // Tecla * para borrar
            if (key_char == '*' && input_pos > 0) {
                input_pos--;
                input_buf[input_pos] = 0;
                
                if (input_pos == 0) {
                    first_digit_entered = 0;
                }
                
                // Actualizar visualizaci�n
                twi_lcd_cmd(0x80 + 11);  // Volver a posici�n inicial
                twi_lcd_msg("        ");  // Limpiar �rea
                twi_lcd_cmd(0x80 + 11);
                if (input_pos > 0) {
                    twi_lcd_msg(input_buf);
                }
            }
            // Entrada de n�meros
            else if (key_char >= '0' && key_char <= '9' && input_pos < 8) {  // L�mite reducido
                // Verificar primer d�gito sea '0'
                if (!first_digit_entered) {
                    if (key_char != '0') {
                        twi_lcd_cmd(0xD4);  // L�nea 3
                        twi_lcd_msg("Debe iniciar con 0");
                        _delay_ms(1500);
                        twi_lcd_cmd(0xD4);
                        twi_lcd_msg("                ");
                        continue;
                    }
                    first_digit_entered = 1;
                }
                
                // A�adir al buffer
                input_buf[input_pos] = key_char;
                input_pos++;
                input_buf[input_pos] = 0;
                
                // Actualizar LCD
                twi_lcd_cmd(0x80 + 11);  // Posici�n del n�mero
                twi_lcd_msg(input_buf);
            }
        }
        
        _delay_ms(50);
    }
    
    // PASO 4: Mostrar confirmaci�n
    twi_lcd_cmd(0x01);
    _delay_ms(2);
    
    if (user_type == 'A') {
        twi_lcd_msg("Estudiante:");
    } else {
        twi_lcd_msg("Colaborador:");
    }
    
    twi_lcd_cmd(0x94);  // L�nea 2
    twi_lcd_msg(user_number);
    twi_lcd_cmd(0xD4);  // L�nea 3
    twi_lcd_msg("Registro completado");
    
    _delay_ms(3000);
}

// Funci�n para obtener el tipo de usuario guardado
char keypad_get_user_type(void) {
    return user_type;
}

// Funci�n para obtener el n�mero guardado
char* keypad_get_user_number(void) {
    return user_number;
}

// FUNCI�N DE DEBUG: Optimizada sin sprintf
void keypad_debug_scan(void) {
    twi_lcd_cmd(0x01);
    twi_lcd_msg("Debug Teclado");
    _delay_ms(1000);
    
    while (1) {
        uint8_t key = keypad_scan();
        if (key != 0xFF) {
            char key_char = keypad_map_to_char(key);
            char num_buf[4];  // CORREGIDO: variable renombrada
            
            twi_lcd_cmd(0x01);
            twi_lcd_msg("Codigo: ");
            
            // Convertir c�digo sin sprintf
            itoa(key, num_buf, 10);  // CORREGIDO: nombre de variable
            twi_lcd_msg(num_buf);    // CORREGIDO: nombre de variable
            
            twi_lcd_cmd(0x94);  // L�nea 2
            twi_lcd_msg("Tecla: ");
            if (key_char != 0) {
                twi_lcd_dwr(key_char);  // Mostrar car�cter directamente
            } else {
                twi_lcd_msg("INVALIDO");
            }
            
            _delay_ms(1500);
        }
        _delay_ms(50);
    }
}