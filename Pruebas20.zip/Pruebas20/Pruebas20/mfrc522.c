/**
 * mfrc522.c - Optimizado para ATmega16
 * Implementaci�n de funciones para control de lectores RFID MFRC522
 * Optimizado para uso m�nimo de RAM
 */

#include "mfrc522.h"
#include <avr/io.h>

// Variables globales optimizadas - UIDs m�s peque�as
static Uid cardUID1;    // UID del primer lector (control de acceso)
static Uid cardUID2;    // UID del segundo lector (detecci�n)
static Uid cardUID3;    // UID del tercer lector (nueva funci�n)
static Uid cardUID4;    // UID del cuarto lector

// Obtener puntero a la UID correspondiente al lector (optimizado)
Uid* getCardUID(uint8_t reader) {
    switch(reader) {
        case 1: return &cardUID1;
        case 2: return &cardUID2;
        case 3: return &cardUID3;
        case 4: return &cardUID4;
        default: return &cardUID1; // Por defecto, primer lector
    }
}

// Funci�n optimizada para seleccionar el lector activo
void selectReader(uint8_t reader) {
    // Optimizaci�n: Primero poner todos en high, luego bajar el seleccionado
    PORTB |= (1<<SS1_PIN)|(1<<SS2_PIN)|(1<<SS3_PIN)|(1<<SS4_PIN);
    
    switch(reader) {
        case 1: PORTB &= ~(1<<SS1_PIN); break;  // SS1 low
        case 2: PORTB &= ~(1<<SS2_PIN); break;  // SS2 low
        case 3: PORTB &= ~(1<<SS3_PIN); break;  // SS3 low
        case 4: PORTB &= ~(1<<SS4_PIN); break;  // SS4 low
    }
}

// Inicializaci�n SPI
void SPI_Init(void) {
    DDRB |= (1<<MOSI_PIN)|(1<<SCK_PIN)|(1<<SS1_PIN)|(1<<SS2_PIN)|(1<<SS3_PIN)|(1<<SS4_PIN);
    DDRB &= ~(1<<MISO_PIN);
    DDRD |= (1<<RST_PIN);
    
    PORTB |= (1<<SS1_PIN)|(1<<SS2_PIN)|(1<<SS3_PIN)|(1<<SS4_PIN);
    
    SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0);
}

// Transferencia SPI
uint8_t SPI_Transfer(uint8_t data) {
    SPDR = data;
    while(!(SPSR & (1<<SPIF)));
    return SPDR;
}

// Inicializar lector MFRC522
void MFRC522_Init(uint8_t reader) {
    MFRC522_Reset(reader);
    
    MFRC522_WriteRegister(TModeReg, 0x8D, reader);
    MFRC522_WriteRegister(TPrescalerReg, 0x3E, reader);
    MFRC522_WriteRegister(TReloadRegL, 30, reader);
    MFRC522_WriteRegister(TReloadRegH, 0, reader);
    
    MFRC522_WriteRegister(TxAutoReg, 0x40, reader);
    MFRC522_WriteRegister(ModeReg, 0x3D, reader);
    
    MFRC522_AntennaOn(reader);
}

// Resetear lector MFRC522
void MFRC522_Reset(uint8_t reader) {
    MFRC522_WriteRegister(CommandReg, PCD_RESETPHASE, reader);
}

// Funci�n Leer registro de MFRC522 optimizada
uint8_t MFRC522_ReadRegister(uint8_t reg, uint8_t reader) {
    uint8_t value;
    selectReader(reader);
    SPI_Transfer(((reg<<1)&0x7E)|0x80);
    value = SPI_Transfer(0x00);
    // Restaurar todos los pins SS
    PORTB |= (1<<SS1_PIN)|(1<<SS2_PIN)|(1<<SS3_PIN)|(1<<SS4_PIN);
    return value;
}

// Funci�n Escribir registro de MFRC522 optimizada
void MFRC522_WriteRegister(uint8_t reg, uint8_t value, uint8_t reader) {
    selectReader(reader);
    SPI_Transfer((reg<<1)&0x7E);
    SPI_Transfer(value);
    // Restaurar todos los pins SS
    PORTB |= (1<<SS1_PIN)|(1<<SS2_PIN)|(1<<SS3_PIN)|(1<<SS4_PIN);
}

// Establecer m�scara de bits en registro
void MFRC522_SetBitMask(uint8_t reg, uint8_t mask, uint8_t reader) {
    uint8_t tmp = MFRC522_ReadRegister(reg, reader);
    MFRC522_WriteRegister(reg, tmp | mask, reader);
}

// Limpiar m�scara de bits en registro
void MFRC522_ClearBitMask(uint8_t reg, uint8_t mask, uint8_t reader) {
    uint8_t tmp = MFRC522_ReadRegister(reg, reader);
    MFRC522_WriteRegister(reg, tmp & (~mask), reader);
}

// Encender antena
void MFRC522_AntennaOn(uint8_t reader) {
    uint8_t temp = MFRC522_ReadRegister(TxControlReg, reader);
    if (!(temp & 0x03)) {
        MFRC522_SetBitMask(TxControlReg, 0x03, reader);
    }
}

// Comunicaci�n con tarjeta (optimizado)
uint8_t MFRC522_ToCard(uint8_t command, uint8_t *sendData, uint8_t sendLen, uint8_t *backData, uint16_t *backLen, uint8_t reader) {
    uint8_t status = MI_ERR;
    uint8_t irqEn = 0x00;
    uint8_t waitIRq = 0x00;
    uint8_t n;
    uint16_t i;
    
    // Optimizaci�n: switch m�s eficiente
    switch (command) {
        case PCD_AUTHENT:
            irqEn = 0x12;
            waitIRq = 0x10;
            break;
        case PCD_TRANSCEIVE:
            irqEn = 0x77;
            waitIRq = 0x30;
            break;
        default:
            break;
    }
    
    MFRC522_WriteRegister(ComIEnReg, irqEn|0x80, reader);
    MFRC522_ClearBitMask(ComIrqReg, 0x80, reader);
    MFRC522_SetBitMask(FIFOLevelReg, 0x80, reader);
    
    MFRC522_WriteRegister(CommandReg, PCD_IDLE, reader);
    
    // Enviar datos
    for (i=0; i<sendLen; i++) {
        MFRC522_WriteRegister(FIFODataReg, sendData[i], reader);
    }
    
    MFRC522_WriteRegister(CommandReg, command, reader);
    if (command == PCD_TRANSCEIVE) {
        MFRC522_SetBitMask(BitFramingReg, 0x80, reader);
    }
    
    // Esperar respuesta
    i = 2000;
    do {
        n = MFRC522_ReadRegister(ComIrqReg, reader);
        i--;
    } while ((i!=0) && !(n&0x01) && !(n&waitIRq));
    
    MFRC522_ClearBitMask(BitFramingReg, 0x80, reader);
    
    if (i != 0) {
        if(!(MFRC522_ReadRegister(ErrorReg, reader) & 0x1B)) {
            status = MI_OK;
            if (n & irqEn & 0x01) {
                status = MI_NOTAGERR;
            }
            
            if (command == PCD_TRANSCEIVE) {
                n = MFRC522_ReadRegister(FIFOLevelReg, reader);
                uint8_t lastBits = MFRC522_ReadRegister(ControlReg, reader) & 0x07;
                
                if (lastBits) {
                    *backLen = (n-1)*8 + lastBits;
                } else {
                    *backLen = n*8;
                }
                
                if (n == 0) n = 1;
                if (n > 16) n = 16;
                
                // Leer datos de respuesta
                for (i=0; i<n; i++) {
                    backData[i] = MFRC522_ReadRegister(FIFODataReg, reader);
                }
            }
        } else {
            status = MI_ERR;
        }
    }
    
    return status;
}

// Enviar solicitud de tarjeta
uint8_t MFRC522_Request(uint8_t reqMode, uint8_t *TagType, uint8_t reader) {
    uint16_t backBits;
    
    MFRC522_WriteRegister(BitFramingReg, 0x07, reader);
    
    TagType[0] = reqMode;
    uint8_t status = MFRC522_ToCard(PCD_TRANSCEIVE, TagType, 1, TagType, &backBits, reader);
    
    if ((status != MI_OK) || (backBits != 0x10)) {
        status = MI_ERR;
    }
    
    return status;
}

// Funci�n de anti-colisi�n optimizada
uint8_t MFRC522_Anticoll(uint8_t *serNum, uint8_t reader) {
    uint8_t serNumCheck = 0;
    uint16_t unLen;
    
    MFRC522_WriteRegister(BitFramingReg, 0x00, reader);
    
    serNum[0] = PICC_CMD_SEL_CL1;
    serNum[1] = 0x20;
    uint8_t status = MFRC522_ToCard(PCD_TRANSCEIVE, serNum, 2, serNum, &unLen, reader);
    
    if (status == MI_OK) {
        // Verificar checksum
        for (uint8_t i=0; i<4; i++) {
            serNumCheck ^= serNum[i];
        }
        if (serNumCheck != serNum[4]) {
            status = MI_ERR;
        }
    }
    
    return status;
}

// Verificar si hay nueva tarjeta presente
uint8_t MFRC522_IsNewCardPresent(uint8_t reader) {
    uint8_t TagType[2];
    return (MFRC522_Request(PICC_CMD_REQA, TagType, reader) == MI_OK) ? 1 : 0;
}

// Leer n�mero de serie de tarjeta (optimizado)
uint8_t MFRC522_ReadCardSerial(uint8_t reader) {
    uint8_t serNum[5];
    
    if (MFRC522_Anticoll(serNum, reader) == MI_OK) {
        // Obtener puntero a la UID correspondiente
        Uid* cardUID = getCardUID(reader);
        
        // Guardar la UID (optimizado)
        cardUID->size = 4; // UID de 4 bytes para tarjetas MIFARE Classic
        for (uint8_t i = 0; i < 4; i++) {
            cardUID->uidByte[i] = serNum[i];
        }
        return 1;
    }
    return 0;
}