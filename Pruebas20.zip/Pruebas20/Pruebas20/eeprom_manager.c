/**
 * eeprom_manager.c
 * Implementaci�n de funciones para gesti�n de UIDs en EEPROM
 */

#include "eeprom_manager.h"
#include "mfrc522.h"
#include "twi_lcd.h"
#include "lcd_utils.h"
#include <avr/io.h>
#include <string.h>

// Funciones de acceso a EEPROM
void EEPROM_write(unsigned int uiAddress, unsigned char ucData) {
    while(EECR & (1<<EEWE));
    EEAR = uiAddress;
    EEDR = ucData;
    EECR |= (1<<EEMWE);
    EECR |= (1<<EEWE);
}

unsigned char EEPROM_read(unsigned int uiAddress) {
    while(EECR & (1<<EEWE));
    EEAR = uiAddress;
    EECR |= (1<<EERE);
    return EEDR;
}

// Inicializar EEPROM si es la primera vez
void initializeEEPROM(void) {
    if (EEPROM_read(EEPROM_START_ADDRESS - 1) != 0xAA) {
        for (uint16_t i = 0; i < (MAX_AUTHORIZED_UIDS * EEPROM_BLOCK_SIZE); i++) {
            EEPROM_write(EEPROM_START_ADDRESS + i, 0xFF);
        }
        EEPROM_write(EEPROM_START_ADDRESS - 1, 0xAA);
    }
}

// Verificar si una UID es v�lida
uint8_t isValidUID(uint8_t* uid) {
    for (uint8_t i = 0; i < UID_SIZE; i++) {
        if (uid[i] != 0xFF && uid[i] != 0x00) {
            return 1;
        }
    }
    return 0;
}

// Buscar el pr�ximo slot libre en EEPROM
uint8_t getNextFreeSlot(void) {
    uint8_t temp_uid[UID_SIZE];
    
    for (uint8_t slot = 0; slot < MAX_AUTHORIZED_UIDS; slot++) {
        for (uint8_t i = 0; i < UID_SIZE; i++) {
            temp_uid[i] = EEPROM_read(EEPROM_START_ADDRESS + (slot * EEPROM_BLOCK_SIZE) + i);
        }
        
        if (!isValidUID(temp_uid)) {
            return slot;
        }
    }
    
    return 0xFF;
}

// Verificar si la UID actual est� autorizada
uint8_t checkUID_Authorization(void) {
    uint8_t temp_uid[UID_SIZE];
    uint8_t match;
    Uid* cardUID1 = getCardUID(1);
    
    for (uint8_t slot = 0; slot < MAX_AUTHORIZED_UIDS; slot++) {
        for (uint8_t i = 0; i < UID_SIZE; i++) {
            temp_uid[i] = EEPROM_read(EEPROM_START_ADDRESS + (slot * EEPROM_BLOCK_SIZE) + i);
        }
        
        if (isValidUID(temp_uid)) {
            match = 1;
            for (uint8_t i = 0; i < UID_SIZE; i++) {
                if (cardUID1->uidByte[i] != temp_uid[i]) {
                    match = 0;
                    break;
                }
            }
            
            if (match) {
                return 1;
            }
        }
    }
    
    return 0;
}

// Agregar nueva UID a EEPROM
uint8_t addUID_ToEEPROM(uint8_t* uid) {
    uint8_t free_slot = getNextFreeSlot();
    
    if (free_slot == 0xFF) {
        return 0;
    }
    
    for (uint8_t i = 0; i < UID_SIZE; i++) {
        EEPROM_write(EEPROM_START_ADDRESS + (free_slot * EEPROM_BLOCK_SIZE) + i, uid[i]);
    }
    
    return 1;
}

// Mostrar cantidad de UIDs autorizadas
void displayAuthorizedCount(void) {
	uint8_t count = 0;
	uint8_t temp_byte;                   // ? Solo 1 byte temporal
	
	// Contar UIDs v�lidas (sin array temporal)
	for (uint8_t slot = 0; slot < MAX_AUTHORIZED_UIDS; slot++) {
		uint8_t valid = 0;
		for (uint8_t i = 0; i < UID_SIZE; i++) {
			temp_byte = EEPROM_read(EEPROM_START_ADDRESS + (slot * EEPROM_BLOCK_SIZE) + i);
			if (temp_byte != 0xFF && temp_byte != 0x00) {
				valid = 1;
				break;                   // ? Salir tan pronto como se detecte v�lido
			}
		}
		if (valid) {
			count++;
		}
	}
	
	twi_lcd_cmd(0x01);
	twi_lcd_msg("UIDs autorizadas:");
	twi_lcd_cmd(0xC0);
	
	// ? Conversi�n optimizada con itoa() y buffer peque�o
	char num_buf[4];                     // ? Solo 4 bytes
	
	// Convertir count
	itoa(count, num_buf, 10);            // ? itoa() es eficiente
	twi_lcd_msg(num_buf);
	
	twi_lcd_msg(" de ");                 // ? String literal directa
	
	// Convertir MAX_AUTHORIZED_UIDS
	itoa(MAX_AUTHORIZED_UIDS, num_buf, 10);  // ? Reutilizar mismo buffer
	twi_lcd_msg(num_buf);
}

uint8_t clearAllUIDs(void) {
	// Mostrar mensaje breve
	twi_lcd_cmd(0x01);
	twi_lcd_msg("Borrando UIDs");
	
	// Borrar todos los slots de UIDs estableciendo los bytes a 0xFF
	for (uint8_t slot = 0; slot < MAX_AUTHORIZED_UIDS; slot++) {
		for (uint8_t i = 0; i < EEPROM_BLOCK_SIZE; i++) {
			EEPROM_write(EEPROM_START_ADDRESS + (slot * EEPROM_BLOCK_SIZE) + i, 0xFF);
		}
		
		// Mostrar progreso simple con puntos
		if (slot % 4 == 0) {
			twi_lcd_dwr('.');
		}
	}
	
	// Mantener el marcador de inicializaci�n
	EEPROM_write(EEPROM_START_ADDRESS - 1, 0xAA);
	
	// Mensaje breve de finalizaci�n
	twi_lcd_cmd(0x01);
	twi_lcd_msg("UIDs Borrados");
	_delay_ms(1000);
	
	return 1;
}