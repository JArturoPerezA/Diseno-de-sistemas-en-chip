/*
 * twi_lcd.c
 *
 * Created: 06/06/2025 02:18:09 p. m.
 *  Author: octav
 */ 
/**
 * twi_lcd.c
 * Implementaci�n de funciones para control de LCD a trav�s de TWI usando PCF8574
 */

#include "twi_lcd.h"
#include <util/delay.h>

// Variable global para operaciones de LCD
static unsigned char lcd = 0x00;

/* Funci�n para escribir datos en PCF8574 */
void PCF8574_write(unsigned char x)
{
    twi_start();                               // Condici�n de inicio
    twi_write_cmd((PCF8574 << 1) | WRITE);     // SLA+W se env�a 0x40
    twi_write_dwr(x);                          // Datos al dispositivo esclavo
    twi_stop();                                // Condici�n de parada
}

/* Funci�n para escribir datos de 4 bits a LCD */
void twi_lcd_4bit_send(unsigned char x)
{
    unsigned char temp = 0x00;                 // Variable temporal para operaciones de datos
    
    lcd &= 0x0F;                               // Enmascarar los �ltimos cuatro bits para evitar RS, RW, EN, Backlight
    temp = (x & 0xF0);                         // Enmascarar los 4 bits superiores de datos y enviarlos a LCD
    lcd |= temp;                               // Datos de 4 bits y pin de control de LCD
    lcd |= (0x04);                             // Bloqueo de datos a LCD EN = 1
    PCF8574_write(lcd);                        // Enviar datos de PCF8574 a puerto LCD
    _delay_us(1);                              // Retardo de 1us
    lcd &= ~(0x04);                            // Bloqueo completo
    PCF8574_write(lcd);                        // Enviar datos de PCF8574 a puerto LCD
    _delay_us(5);                              // Retardo de 5us para completar el bloqueo
    
    temp = ((x & 0x0F)<<4);                    // Enmascarar los 4 bits inferiores de datos y enviarlos a LCD
    lcd &= 0x0F;                               // Enmascarar los �ltimos cuatro bits para evitar RS, RW, EN, Backlight
    lcd |= temp;                               // Datos de 4 bits y pin de control de LCD
    lcd |= (0x04);                             // Bloqueo de datos a LCD EN = 1
    PCF8574_write(lcd);                        // Enviar datos de PCF8574 a puerto LCD
    _delay_us(1);                              // Retardo de 1us
    lcd &= ~(0x04);                            // Bloqueo completo
    PCF8574_write(lcd);                        // Enviar datos de PCF8574 a puerto LCD
    _delay_us(5);                              // Retardo de 5us para completar el bloqueo
}

/* Funci�n para escribir en el registro de comandos de LCD */
void twi_lcd_cmd(unsigned char x)
{
    lcd = 0x08;                                // Habilitar pin de retroiluminaci�n
    lcd &= ~(0x01);                            // Seleccionar registro de comandos con RS = 0
    PCF8574_write(lcd);                        // Enviar datos de PCF8574 a puerto LCD
    twi_lcd_4bit_send(x);                      // Funci�n para escribir datos de 4 bits a LCD
}

/* Funci�n para escribir en el registro de datos de LCD */
void twi_lcd_dwr(unsigned char x)
{
    lcd |= 0x09;                               // Habilitar pin de retroiluminaci�n y seleccionar registro de datos con RS = 1
    PCF8574_write(lcd);                        // Enviar datos de PCF8574 a puerto LCD
    twi_lcd_4bit_send(x);                      // Funci�n para escribir datos de 4 bits a LCD
}

/* Funci�n para enviar cadena de datos */
void twi_lcd_msg(char *c)
{
    while (*c != '\0')                         // Verificar puntero para nulo
        twi_lcd_dwr(*c++);                     // Enviar la cadena de datos
}

/* Funci�n para ejecutar el comando de borrado de LCD */
void twi_lcd_clear(void)
{
    twi_lcd_cmd(0x01);
}

/* Funci�n para inicializar LCD en modo de 4 bits, configuraci�n de cursor y selecci�n de fila */
void twi_lcd_init(void)
{
    lcd = 0x04;                                // EN = 1 para inicializar secuencia de 25us
    PCF8574_write(lcd);
    _delay_us(25);
    
    twi_lcd_cmd(0x03);                         // Secuencia de inicializaci�n
    twi_lcd_cmd(0x03);                         // Secuencia de inicializaci�n
    twi_lcd_cmd(0x03);                         // Secuencia de inicializaci�n
    twi_lcd_cmd(0x02);                         // Volver a inicio
    twi_lcd_cmd(0x28);                         // Modo de 4 bits, selecci�n de 2 filas
    twi_lcd_cmd(0x0F);                         // Cursor activado, parpadeo activado
    twi_lcd_cmd(0x01);                         // Borrar LCD
    twi_lcd_cmd(0x06);                         // Incremento autom�tico del cursor
    twi_lcd_cmd(0x80);                         // Direcci�n de fila 1 columna 1
    twi_lcd_cmd(0x0C);                         // Display on, cursor off
}