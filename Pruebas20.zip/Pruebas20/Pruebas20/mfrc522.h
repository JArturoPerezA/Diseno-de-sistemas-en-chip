/**
 * mfrc522.h - Optimizado para ATmega16
 * Definiciones y prototipos para el control de lectores RFID MFRC522
 * Optimizado para uso m�nimo de RAM
 */

#ifndef MFRC522_H
#define MFRC522_H

#include <avr/io.h>

// Definiciones de pines para ATmega16
#define SS1_PIN     PB4     // Pin 5 (SS para primer lector - Control de acceso)
#define SS2_PIN     PB3     // Pin 4 (SS para segundo lector - Detecci�n)
#define SS3_PIN     PB2     // Pin 3 (SS para tercer lector - Nueva funci�n)
#define SS4_PIN     PB1     // Pin 2 (SS para cuarto lector)
#define MOSI_PIN    PB5     // Pin 6 (MOSI) - Compartido
#define MISO_PIN    PB6     // Pin 7 (MISO) - Compartido
#define SCK_PIN     PB7     // Pin 8 (SCK) - Compartido
#define RST_PIN     PB0     // Pin 16 (RST) - Compartido

// Comandos MFRC522
#define PCD_IDLE                0x00
#define PCD_AUTHENT             0x0E
#define PCD_RECEIVE             0x08
#define PCD_TRANSMIT            0x04
#define PCD_TRANSCEIVE          0x0C
#define PCD_RESETPHASE          0x0F
#define PCD_CALCCRC             0x03

// Registros MFRC522 m�s usados (optimizaci�n: solo los necesarios)
#define CommandReg              0x01
#define ComIEnReg               0x02
#define ComIrqReg               0x04
#define ErrorReg                0x06
#define Status1Reg              0x07
#define Status2Reg              0x08
#define FIFODataReg             0x09
#define FIFOLevelReg            0x0A
#define ControlReg              0x0C
#define BitFramingReg           0x0D
#define ModeReg                 0x11
#define TxControlReg            0x14
#define TxAutoReg               0x15
#define TModeReg                0x2A
#define TPrescalerReg           0x2B
#define TReloadRegH             0x2C
#define TReloadRegL             0x2D
#define VersionReg              0x37

// Comandos PICC
#define PICC_CMD_REQA           0x26
#define PICC_CMD_SEL_CL1        0x93
#define PICC_CMD_HLTA           0x50

// Estados de retorno
#define MI_OK                   0
#define MI_NOTAGERR             1
#define MI_ERR                  2

// Estructura optimizada para almacenar la UID (reducida de 10 a 4 bytes)
typedef struct {
    uint8_t size;               // Tama�o de la UID
    uint8_t uidByte[4];         // UID optimizada: solo 4 bytes (era 10)
    uint8_t sak;                // SAK (Select acknowledge)
} Uid;

// Prototipos de funciones SPI
void SPI_Init(void);
uint8_t SPI_Transfer(uint8_t data);

// Prototipos de funciones MFRC522
void MFRC522_Init(uint8_t reader);
void MFRC522_Reset(uint8_t reader);
uint8_t MFRC522_ReadRegister(uint8_t reg, uint8_t reader);
void MFRC522_WriteRegister(uint8_t reg, uint8_t value, uint8_t reader);
void MFRC522_SetBitMask(uint8_t reg, uint8_t mask, uint8_t reader);
void MFRC522_ClearBitMask(uint8_t reg, uint8_t mask, uint8_t reader);
void MFRC522_AntennaOn(uint8_t reader);
uint8_t MFRC522_ToCard(uint8_t command, uint8_t *sendData, uint8_t sendLen, uint8_t *backData, uint16_t *backLen, uint8_t reader);
uint8_t MFRC522_Request(uint8_t reqMode, uint8_t *TagType, uint8_t reader);
uint8_t MFRC522_Anticoll(uint8_t *serNum, uint8_t reader);
uint8_t MFRC522_IsNewCardPresent(uint8_t reader);
uint8_t MFRC522_ReadCardSerial(uint8_t reader);
void selectReader(uint8_t reader);
Uid* getCardUID(uint8_t reader);

#endif /* MFRC522_H */