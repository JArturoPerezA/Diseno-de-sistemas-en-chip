/**
 * lcd_utils.h
 * Utilidades para manejo de la pantalla LCD
 */

#ifndef LCD_UTILS_H
#define LCD_UTILS_H

#include <avr/io.h>

// Prototipos de funciones para LCD
void byteToHex(uint8_t value, char* hexString);
void displayUID_LCD(uint8_t reader);
void displayAccessResult(uint8_t access_granted);

#endif /* LCD_UTILS_H */