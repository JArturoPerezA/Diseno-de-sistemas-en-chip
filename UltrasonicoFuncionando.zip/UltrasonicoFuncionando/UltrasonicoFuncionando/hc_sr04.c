/**
 * HC-SR04 Ultrasonic Sensor Library
 * Implementation file for HC-SR04 sensor with TWI LCD display
 */

#define F_CPU 8000000UL  // 8 MHz

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdlib.h>
#include <string.h>
#include "hc_sr04.h"
#include "twi_lcd.h"

// Variable global del sensor
volatile hc_sr04_data_t sensor_data = {0, 0, 0, 0, 0, SENSOR_IDLE};

// Variables para optimizaci�n del display
static int last_distance = -1;
static uint8_t last_error = 2;  // Valor inicial diferente para forzar primera actualizaci�n

// === INTERRUPCIONES ===

// Interrupci�n por overflow del Timer0
ISR (TIMER0_OVF_vect) {
    if(sensor_data.rising_edge == 1) {
        sensor_data.timer_value++;
        // Verificar si est� fuera de rango
        if(sensor_data.timer_value > TIMEOUT_COUNTS) {
            sensor_data.measuring = 0;
            sensor_data.rising_edge = 0;
            sensor_data.error = 1;
            sensor_data.state = SENSOR_ERROR;
        }
    }
}

// Interrupci�n externa INT1 para el pin de echo
ISR (INT1_vect) {
    if(sensor_data.measuring == 1) {
        if(sensor_data.rising_edge == 0) {
            // Flanco de subida - iniciar medici�n
            sensor_data.rising_edge = 1;
            TCNT0 = 0;
            sensor_data.timer_value = 0;
        }
        else {
            // Flanco de bajada - calcular distancia
            sensor_data.rising_edge = 0;
            sensor_data.distance_cm = (sensor_data.timer_value * 256 + TCNT0) / DISTANCE_FACTOR;
            sensor_data.measuring = 0;
            sensor_data.state = SENSOR_DATA_READY;
        }
    }
}

// === FUNCIONES PRIVADAS ===

static void initialize_external_interrupt(void) {
    MCUCR |= (1 << ISC10);  // Cualquier cambio l�gico en INT1
    GICR |= (1 << INT1);    // Habilitar INT1
}

static void initialize_timer0(void) {
    TCCR0 |= (1 << CS00);   // Sin prescaler
    TCNT0 = 0;              // Reset timer
    TIMSK |= (1 << TOIE0);  // Habilitar interrupci�n por overflow
}

static void configure_pins(void) {
    TRIGGER_DDR |= (1 << TRIGGER_PIN);   // Pin trigger como salida
    ECHO_DDR &= ~(1 << ECHO_PIN);        // Pin echo como entrada
}

static void send_trigger_pulse(void) {
    TRIGGER_PORT &= ~(1 << TRIGGER_PIN);  // Trigger bajo
    _delay_us(2);
    TRIGGER_PORT |= (1 << TRIGGER_PIN);   // Pulso de 10us
    _delay_us(10);
    TRIGGER_PORT &= ~(1 << TRIGGER_PIN);  // Trigger bajo
}

// === FUNCIONES DE DISPLAY ===

static void go_to_position(uint8_t column, uint8_t row) {
    uint8_t position;
    
    if (row == 0) {
        position = 0x80 + column;  // Primera l�nea: 0x80 + columna
    } else {
        position = 0xC0 + column;  // Segunda l�nea: 0xC0 + columna
    }
    
    twi_lcd_cmd(position);
}

static void clear_position(uint8_t column, uint8_t count) {
    go_to_position(column, 0);
    for(uint8_t i = 0; i < count; i++) {
        twi_lcd_dwr(' ');  // Enviar espacio
    }
}

// === FUNCIONES P�BLICAS ===

void hc_sr04_init(void) {
    // Inicializar estructura de datos
    sensor_data.distance_cm = 0;
    sensor_data.error = 0;
    sensor_data.measuring = 0;
    sensor_data.timer_value = 0;
    sensor_data.rising_edge = 0;
    sensor_data.state = SENSOR_IDLE;
    
    // Configurar hardware
    configure_pins();
    initialize_external_interrupt();
    initialize_timer0();
    
    // Habilitar interrupciones globales
    sei();
}

void hc_sr04_trigger_measurement(void) {
    if(sensor_data.measuring == 0 && sensor_data.state != SENSOR_MEASURING) {
        _delay_ms(50); // Pausa entre mediciones
        send_trigger_pulse();
        sensor_data.measuring = 1;
        sensor_data.error = 0;
        sensor_data.state = SENSOR_MEASURING;
    }
}

sensor_state_t hc_sr04_get_state(void) {
    return sensor_data.state;
}

int hc_sr04_get_distance(void) {
    if(sensor_data.state == SENSOR_DATA_READY && !sensor_data.error) {
        sensor_data.state = SENSOR_IDLE;  // Marcar como le�do
        return sensor_data.distance_cm;
    }
    return -1;  // Error o sin datos
}

uint8_t hc_sr04_has_error(void) {
    return sensor_data.error;
}

void hc_sr04_clear_error(void) {
    sensor_data.error = 0;
    sensor_data.state = SENSOR_IDLE;
}

uint8_t hc_sr04_is_measuring(void) {
    return sensor_data.measuring;
}

// === FUNCIONES DE DISPLAY ===

void hc_sr04_display_init(void) {
    twi_init();         // Inicializar TWI
    twi_lcd_init();     // Inicializar LCD TWI
    
    // Mostrar mensaje inicial
    twi_lcd_cmd(0x01);  // Clear display
    twi_lcd_msg("Sensor Ultrason.");
    twi_lcd_cmd(0xC0);  // Segunda l�nea
    twi_lcd_msg("Iniciando...");
    _delay_ms(2000);
    
    // Limpiar pantalla para operaci�n normal
    twi_lcd_cmd(0x01);
    
    // Reset variables de display
    last_distance = -1;
    last_error = 2;
}

void hc_sr04_display_update(void) {
    char value[6];  // Buffer para n�meros de 3 d�gitos
    
    // Solo actualizar si hay cambios
    if (sensor_data.distance_cm != last_distance || sensor_data.error != last_error) {
        
        // Limpiar �rea de la distancia anterior
        clear_position(11, 5);  // Limpiar "XXX cm" o "---"
        
        // Mostrar texto fijo si es la primera vez
        if (last_distance == -1) {
            go_to_position(0, 0);
            twi_lcd_msg("Distance = ");
        }
        
        if (sensor_data.error == 1) {
            go_to_position(11, 0);
            twi_lcd_msg("---");
        } else {
            // Convertir distancia a string
            itoa(sensor_data.distance_cm, value, 10);
            
            go_to_position(11, 0);
            twi_lcd_msg(value);
            go_to_position(14, 0);
            twi_lcd_msg("cm");
        }
        
        // Actualizar valores anteriores
        last_distance = sensor_data.distance_cm;
        last_error = sensor_data.error;
    }
}

void hc_sr04_display_clear(void) {
    twi_lcd_cmd(0x01);  // Clear display
    last_distance = -1;
    last_error = 2;
}

void hc_sr04_display_message(const char* message) {
    twi_lcd_cmd(0x01);  // Clear display
    twi_lcd_msg(message);
}

// === FUNCIONES DE UTILIDAD ===

void hc_sr04_delay_ms(uint16_t ms) {
    while(ms--) {
        _delay_ms(1);
    }
}

void hc_sr04_test_sensor(uint8_t num_tests) {
    hc_sr04_display_clear();
    twi_lcd_msg("Test HC-SR04");
    twi_lcd_cmd(0xC0);
    twi_lcd_msg("Verificando...");
    _delay_ms(2000);
    
    // Realizar mediciones de prueba
    for(uint8_t i = 0; i < num_tests; i++) {
        hc_sr04_trigger_measurement();
        
        // Esperar a que termine la medici�n
        while(hc_sr04_get_state() == SENSOR_MEASURING) {
            _delay_ms(10);
        }
        
        hc_sr04_display_clear();
        twi_lcd_msg("Test ");
        twi_lcd_dwr('0' + i + 1);
        twi_lcd_msg(": ");
        
        int distance = hc_sr04_get_distance();
        if(distance >= 0) {
            char test_value[6];
            itoa(distance, test_value, 10);
            twi_lcd_msg(test_value);
            twi_lcd_msg("cm");
        } else {
            twi_lcd_msg("Error");
            hc_sr04_clear_error();
        }
        
        _delay_ms(1000);
    }
    
    hc_sr04_display_clear();
    twi_lcd_msg("Test completado");
    _delay_ms(2000);
    hc_sr04_display_clear();
}