/**
 * HC-SR04 Ultrasonic Sensor Library
 * Header file for HC-SR04 sensor with TWI LCD display
 */

#ifndef HC_SR04_H
#define HC_SR04_H

#include <avr/io.h>
#include <stdint.h>

// Configuraci�n de pines
#define TRIGGER_PORT    PORTD
#define TRIGGER_DDR     DDRD
#define TRIGGER_PIN     PIND4

#define ECHO_PORT       PORTD
#define ECHO_DDR        DDRD
#define ECHO_PIN        PIND3

// Configuraci�n del sensor
#define MAX_DISTANCE_CM     400     // Distancia m�xima en cm
#define TIMEOUT_COUNTS      91      // Valor de timeout para el timer
#define DISTANCE_FACTOR     58      // Factor de conversi�n para distancia

// Estados del sensor
typedef enum {
    SENSOR_IDLE = 0,
    SENSOR_MEASURING,
    SENSOR_DATA_READY,
    SENSOR_ERROR
} sensor_state_t;

// Estructura de datos del sensor
typedef struct {
    int distance_cm;            // Distancia medida en cm
    uint8_t error;              // Flag de error
    uint8_t measuring;          // Flag de medici�n en curso
    uint16_t timer_value;       // Valor del timer para c�lculos
    uint8_t rising_edge;        // Flag de flanco de subida
    sensor_state_t state;       // Estado actual del sensor
} hc_sr04_data_t;

// Variables globales del sensor
extern volatile hc_sr04_data_t sensor_data;

// Funciones p�blicas del sensor
void hc_sr04_init(void);
void hc_sr04_trigger_measurement(void);
sensor_state_t hc_sr04_get_state(void);
int hc_sr04_get_distance(void);
uint8_t hc_sr04_has_error(void);
void hc_sr04_clear_error(void);
uint8_t hc_sr04_is_measuring(void);

// Funciones de display (opcional - pueden moverse a otro m�dulo)
void hc_sr04_display_init(void);
void hc_sr04_display_update(void);
void hc_sr04_display_clear(void);
void hc_sr04_display_message(const char* message);

// Funciones de utilidad
void hc_sr04_delay_ms(uint16_t ms);
void hc_sr04_test_sensor(uint8_t num_tests);

#endif // HC_SR04_H