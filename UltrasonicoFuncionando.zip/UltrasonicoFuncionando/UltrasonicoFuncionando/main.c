/**
 * Ejemplo de uso del sensor HC-SR04 con medici�n continua
 * Este archivo demuestra c�mo usar la librer�a hc_sr04 para
 * realizar mediciones continuas y mostrar los resultados
 */

#define F_CPU 8000000UL  // 8 MHz

#include <avr/io.h>
#include <util/delay.h>
#include "hc_sr04.h"

int main(void) {
    // Inicializar el sensor y el display
    hc_sr04_init();
    hc_sr04_display_init();
    
    // Ejecutar test inicial (opcional)
    hc_sr04_test_sensor(3);
    
    // Bucle principal de medici�n continua
    while(1) {
        // Disparar una nueva medici�n
        hc_sr04_trigger_measurement();
        
        // Esperar un poco para que se complete la medici�n
        _delay_ms(100);
        
        // Actualizar el display con los nuevos datos
        hc_sr04_display_update();
        
        // Verificar si hay errores
        if(hc_sr04_has_error()) {
            // Manejar error si es necesario
            _delay_ms(500);  // Pausa adicional en caso de error
            hc_sr04_clear_error();
        }
        
        // Pausa entre mediciones
        _delay_ms(200);
    }
    
    return 0;
}

// Ejemplo alternativo: medici�n bajo demanda
/*
int main_on_demand_example(void) {
    int distance;
    
    // Inicializar sistema
    hc_sr04_init();
    hc_sr04_display_init();
    
    while(1) {
        // Disparar medici�n
        hc_sr04_trigger_measurement();
        
        // Esperar hasta que la medici�n est� lista
        while(hc_sr04_get_state() == SENSOR_MEASURING) {
            _delay_ms(10);
        }
        
        // Obtener resultado
        distance = hc_sr04_get_distance();
        
        if(distance >= 0) {
            // Medici�n exitosa - actualizar display
            hc_sr04_display_update();
            
            // Aqu� puedes procesar la distancia como necesites
            // Por ejemplo, controlar actuadores, enviar datos, etc.
            
        } else {
            // Error en la medici�n
            hc_sr04_display_message("Error medicion");
            _delay_ms(1000);
            hc_sr04_clear_error();
        }
        
        // Pausa entre mediciones
        _delay_ms(500);
    }
    
    return 0;
}
*/