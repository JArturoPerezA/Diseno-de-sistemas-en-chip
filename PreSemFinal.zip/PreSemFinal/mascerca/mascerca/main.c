/**
 * main.c (Optimizado)
 * Sistema de control dual RFID con ATmega16
 * 
 * Este archivo contiene la funci�n principal y la l�gica del sistema optimizada
 */

#define F_CPU 8000000UL  // 8 MHz

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <string.h>
#include "twi_lcd.h"
#include "mfrc522.h"
#include "eeprom_manager.h"
#include "keypad.h"
#include "lcd_utils.h"

//Servo
#define SERVO_DDR DDRD
#define SERVO_PORT PORTD
#define SERVO_PIN PD5

// Definici�n del pin para LED
#define LED_PIN     PD7

// Constantes para los sensores
#define SENSOR_COUNT 4
#define SENSOR_ACCESS 0   // �ndice para el sensor de control de acceso (1)
#define SENSOR_DETECT1 1  // �ndice para el sensor de detecci�n (2)
#define SENSOR_DETECT2 2  // �ndice para el sensor de funciones adicionales (3)
#define SENSOR_DETECT3 3  // �ndice para el cuarto sensor (4)

// Estructura para manejar el estado de cada sensor
typedef struct {
    uint8_t id;               // ID del sensor (1-4)
    uint8_t cardPresent;      // Bandera de tarjeta presente
    uint8_t busy;             // Bandera de sensor ocupado
    void (*processCard)();    // Funci�n para procesar la tarjeta detectada
} SensorState;

// Variables globales
uint8_t displayTimer = 0;     // Contador para actualizar el display
SensorState sensors[SENSOR_COUNT]; // Array para manejar los 4 sensores

// Funciones de manejo de LED
void LED_Init(void) {
    DDRD |= (1<<LED_PIN);  // Configurar pin de LED como salida
    PORTD &= ~(1<<LED_PIN); // Inicialmente apagado
}

void LED_On(void) {
    PORTD |= (1<<LED_PIN);
}

void LED_Off(void) {
    PORTD &= ~(1<<LED_PIN);
}

// Procesamiento para el sensor de acceso (Sensor 1)
void processAccessSensor() {
    // Mostrar UID del sensor 1
    displayUID_LCD(1);
    _delay_ms(1500);
    
    // Verificar autorizaci�n
    uint8_t access_granted = checkUID_Authorization();
    
    // Mostrar resultado del acceso
    displayAccessResult(access_granted);
    
    // Si no est� autorizada, preguntar si se desea agregar
    if (!access_granted) {
        twi_lcd_cmd(0x01);
        twi_lcd_msg("Agregar UID?");
        twi_lcd_cmd(0xC0);
        twi_lcd_msg("Espere 3s = SI");
        
        _delay_ms(3000);
        
        if (addUID_ToEEPROM(getCardUID(1)->uidByte)) {
            twi_lcd_cmd(0x01);
            twi_lcd_msg("UID Agregada!");
            twi_lcd_cmd(0xC0);
            twi_lcd_msg("Exitosamente");
        } else {
            twi_lcd_cmd(0x01);
            twi_lcd_msg("Memoria llena!");
            twi_lcd_cmd(0xC0);
            twi_lcd_msg("No se agrego");
        }
        _delay_ms(2000);
        
        displayAuthorizedCount();
        _delay_ms(2000);
    }
    
    displayTimer = 50; // Mantener display por 5 segundos
}

// Procesamiento para el sensor de detecci�n (Sensor 2)
void processDetectSensor1() {
    // Encender LED
    LED_On();
    _delay_ms(3000);
    LED_Off();
    
    // Mostrar detecci�n en LCD si no hay operaci�n del sensor 1
    if (displayTimer == 0) {
        twi_lcd_cmd(0x01);
        twi_lcd_msg("Sensor 2: Detect");
        twi_lcd_cmd(0xC0);
        twi_lcd_msg("LED Activado");
        displayTimer = 20; // Mostrar por 2 segundos
    }
}

// Procesamiento para el sensor 3
void processDetectSensor2() {
    // Encender LED
    LED_On();
	keypad_get_input();		

    LED_Off();
        twi_lcd_cmd(0x01);
        twi_lcd_msg("Saliendo del");
        twi_lcd_cmd(0xC0);
        twi_lcd_msg("modo teclado");
        displayTimer = 20; // Mostrar por 2 segundos
    // Mostrar detecci�n en LCD
    if (displayTimer == 0) {
        twi_lcd_cmd(0x01);
        twi_lcd_msg("Sensor 3: Detect");
        twi_lcd_cmd(0xC0);
        twi_lcd_msg("LED Activado");
        displayTimer = 20; // Mostrar por 2 segundos
    }
}

// Procesamiento para el sensor 4
void processDetectSensor3() {
    // Encender LED
    LED_On();
    _delay_ms(3000);
    LED_Off();
    
    // Mostrar detecci�n en LCD
    if (displayTimer == 0) {
        twi_lcd_cmd(0x01);
        twi_lcd_msg("Sensor 4: Detect");
        twi_lcd_cmd(0xC0);
        twi_lcd_msg("LED Activado");
        displayTimer = 20; // Mostrar por 2 segundos
    }
}

// Funci�n de prueba para cualquier sensor RFID
void testSensor(uint8_t sensorNum) {
    uint8_t version;
    
    // Leer versi�n del sensor especificado
    version = MFRC522_ReadRegister(VersionReg, sensorNum);
    
    twi_lcd_cmd(0x01);
    twi_lcd_msg("Test Sensor ");
    
    // Convertir n�mero de sensor a car�cter y mostrarlo
    char sensorChar = '0' + sensorNum;
    twi_lcd_dwr(sensorChar);
    twi_lcd_msg(":");
    
    twi_lcd_cmd(0xC0);
    
    if (version == 0x91 || version == 0x92) {
        twi_lcd_msg("OK - Version:");
        char hex[3];
        byteToHex(version, hex);
        twi_lcd_msg(hex);
    } else if (version == 0x00 || version == 0xFF) {
        twi_lcd_msg("Error conexion");
    } else {
        twi_lcd_msg("Version:");
        char hex[3];
        byteToHex(version, hex);
        twi_lcd_msg(hex);
    }
    
    _delay_ms(2000);
}

// Inicializar los sensores
void initSensors() {
    // Inicializar sensor 1 (control de acceso)
    sensors[SENSOR_ACCESS].id = 1;
    sensors[SENSOR_ACCESS].cardPresent = 0;
    sensors[SENSOR_ACCESS].busy = 0;
    sensors[SENSOR_ACCESS].processCard = processAccessSensor;
    
    // Inicializar sensor 2 (detecci�n)
    sensors[SENSOR_DETECT1].id = 2;
    sensors[SENSOR_DETECT1].cardPresent = 0;
    sensors[SENSOR_DETECT1].busy = 0;
    sensors[SENSOR_DETECT1].processCard = processDetectSensor1;
    
    // Inicializar sensor 3
    sensors[SENSOR_DETECT2].id = 3;
    sensors[SENSOR_DETECT2].cardPresent = 0;
    sensors[SENSOR_DETECT2].busy = 0;
    sensors[SENSOR_DETECT2].processCard = processDetectSensor2;
    
    // Inicializar sensor 4
    sensors[SENSOR_DETECT3].id = 4;
    sensors[SENSOR_DETECT3].cardPresent = 0;
    sensors[SENSOR_DETECT3].busy = 0;
    sensors[SENSOR_DETECT3].processCard = processDetectSensor3;
}

// Manejar todos los sensores RFID
void handleRFIDSensors() {
    // Sensor de acceso tiene prioridad
    if (MFRC522_IsNewCardPresent(sensors[SENSOR_ACCESS].id)) {
        if (MFRC522_ReadCardSerial(sensors[SENSOR_ACCESS].id)) {
            sensors[SENSOR_ACCESS].cardPresent = 1;
            sensors[SENSOR_ACCESS].busy = 1;
            
            // Procesar tarjeta para sensor de acceso
            sensors[SENSOR_ACCESS].processCard();
            
            // Peque�a pausa antes de continuar
            _delay_ms(500);
            sensors[SENSOR_ACCESS].busy = 0;
            return; // Salir y no verificar otros sensores en este ciclo
        }
    }
    
    // Si el sensor de acceso no est� ocupado, verificar los otros sensores
    if (!sensors[SENSOR_ACCESS].busy) {
        // Iterar sobre los sensores de detecci�n (sensores 2, 3 y 4)
        for (uint8_t i = SENSOR_DETECT1; i < SENSOR_COUNT; i++) {
            if (MFRC522_IsNewCardPresent(sensors[i].id)) {
                if (MFRC522_ReadCardSerial(sensors[i].id)) {
                    sensors[i].cardPresent = 1;
                    
                    // Procesar tarjeta para este sensor
                    sensors[i].processCard();
                    
                    // Peque�a pausa antes de continuar
                    _delay_ms(500);
                    return; // Salir despu�s de procesar un sensor
                }
            }
        }
    }
}

// Actualizar el LCD seg�n sea necesario
void updateDisplay() {
    // Control del temporizador del display
    if (displayTimer > 0) {
        displayTimer--;
        if (displayTimer == 0) {
            // Restaurar mensaje normal
            twi_lcd_cmd(0x01);
            twi_lcd_msg("S1:Acc S2:Det S3");
            twi_lcd_cmd(0xC0);
            twi_lcd_msg("Esperando...");
            
            // Restablecer banderas de tarjeta presente
            for (uint8_t i = 0; i < SENSOR_COUNT; i++) {
                sensors[i].cardPresent = 0;
            }
        }
    }
}

int main(void) {
    // Inicializaci�n
    twi_init();                 // TWI Initialize
    twi_lcd_init();             // TWI LCD Initialize
    SPI_Init();                 // SPI Initialize
    LED_Init();                 // LED Initialize
	DDRA = 0x0F;  // PA0-PA3 salidas, PA4-PA7 entradas
	PORTA = 0xF0; // Pull-ups en columnas, filas inicialmente bajas
    keypad_init();
    // Inicializar los cuatro lectores RFID
    MFRC522_Init(1);            // Inicializar primer lector (control de acceso)
    MFRC522_Init(2);            // Inicializar segundo lector (detecci�n)
    MFRC522_Init(3);            // Inicializar tercer lector (nueva funci�n)
    MFRC522_Init(4);            // Inicializar cuarto lector
    
    // Inicializar PWM para el servo
    DDRD |= (1<<PD5);           // Configurar PD5 como salida (OC1A)
    TCNT1 = 0;                  // Inicializar contador del Timer1
    ICR1 = 2499;                // Valor TOP para frecuencia de 50Hz (20ms)
    
    // Configurar Timer1 en modo PWM fase correcta con TOP en ICR1
    TCCR1A = (1<<WGM11)|(1<<COM1A1);  // PWM no invertido en OC1A
    TCCR1B = (1<<WGM13)|(1<<WGM12)|(1<<CS11)|(1<<CS10); // Prescaler 64
    
    // Inicializar EEPROM para control de acceso
    initializeEEPROM();
    
    // Inicializar estructura de sensores
    initSensors();
    
    // Mostrar mensaje inicial
    twi_lcd_cmd(0x01);          // Clear display
    twi_lcd_msg("Sistema cuatro");
    twi_lcd_cmd(0xC0);          // Segunda l�nea
    twi_lcd_msg("RFID Iniciando...");
    
    _delay_ms(2000);
    
    // Probar los sensores
    testSensor(1);
    testSensor(2);
    testSensor(3);
    testSensor(4);
    
    // Mostrar cantidad de UIDs autorizadas
    displayAuthorizedCount();
    _delay_ms(2000);
    
    // Mostrar mensaje de operaci�n normal
    twi_lcd_cmd(0x01);
    twi_lcd_msg("S1:Acc S2:Det S3");
    twi_lcd_cmd(0xC0);
    twi_lcd_msg("Esperando...");
    
    // Bucle principal
    while(1) {
        // Verificar y manejar los sensores RFID
        handleRFIDSensors();
        
        // Actualizar el display si es necesario
        updateDisplay();
        
        _delay_ms(100); // Pausa de 100ms entre iteraciones
    }
    
    return 0;
}
