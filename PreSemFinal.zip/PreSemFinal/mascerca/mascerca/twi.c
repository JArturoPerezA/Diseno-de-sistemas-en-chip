/**
 * twi.c
 * Implementaci�n de funciones TWI (I2C)
 */

#include "twi.h"

void twi_init(void)
{
    DDRC = 0x03;                                // PORTC �ltimos dos bits como salida
    PORTC = 0x03;
    
    usart_init();                               // Inicializaci�n USART
    usart_msg("TWI Init...");                   // Env�a cadena al puerto COM del PC
    usart_tx(0x0d);                             // Nueva l�nea
    
    TWCR &= ~(1<<TWEN);                         // Deshabilita TWI
    TWBR = BITRATE(TWSR = 0x00);                // Tasa de bits con prescaler 4
    TWCR = (1<<TWEN);                           // Habilita TWI
    _delay_us(10);                              // Retardo
}

/* Funci�n para enviar condici�n de inicio */
void twi_start(void)
{
    TWCR = (1<<TWINT)|(1<<TWSTA)|(1<<TWEN);     // Condici�n de inicio seg�n hoja de datos
    while(!(TWCR & (1<<TWINT)));                // Esperar hasta que se transmita la condici�n de inicio al esclavo
    while(TW_STATUS != TW_START);               // Verificar el reconocimiento 0x08 = TW_START
    usart_msg("Start Exe.");                    // Mensaje de retroalimentaci�n para verificar errores
    usart_tx(0x0D);                             // Nueva l�nea
}

/* Funci�n para enviar direcci�n de esclavo para operaci�n de escritura */
void twi_write_cmd(unsigned char address)
{
    TWDR = address;                             // Direcci�n SLA e instrucci�n de escritura
    TWCR = (1<<TWINT)|(1<<TWEN);                // Limpiar bandera de interrupci�n TWI, habilitar TWI
    while (!(TWCR & (1<<TWINT)));               // Esperar hasta que se transmita el byte TWDR completo al esclavo
    while(TW_STATUS != TW_MT_SLA_ACK);          // Verificar el reconocimiento
    usart_msg("ACK Received for MT SLA");       // Mensaje de retroalimentaci�n para verificar errores
    usart_tx(0x0D);                             // Nueva l�nea
}

/* Funci�n para enviar datos al dispositivo esclavo */
void twi_write_dwr(unsigned char data)
{
    TWDR = data;                                // Poner datos en TWDR
    TWCR = (1<<TWINT)|(1<<TWEN);                // Limpiar bandera de interrupci�n TWI, habilitar TWI
    while (!(TWCR & (1<<TWINT)));               // Esperar hasta que se transmita el byte TWDR completo al esclavo
    while(TW_STATUS != TW_MT_DATA_ACK);         // Verificar el reconocimiento
    usart_msg("ACK Received for MT Data");      // Mensaje de retroalimentaci�n para verificar errores
    usart_tx(0x0D);                             // Nueva l�nea
}

/* Funci�n para enviar condici�n de parada */
void twi_stop(void)
{
    TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);     // Condici�n de parada seg�n hoja de datos
}

/* Funci�n para enviar condici�n de inicio repetida */
void twi_repeated_start(void)
{
    TWCR = (1<<TWINT)|(1<<TWSTA)|(1<<TWEN);     // Condici�n de inicio repetida seg�n hoja de datos
    while(!(TWCR & (1<<TWINT)));                // Esperar hasta que se transmita la condici�n de reinicio al esclavo
    while(TW_STATUS != TW_REP_START);           // Verificar el reconocimiento
    usart_msg("Repeated Start Exe.");           // Mensaje de retroalimentaci�n para verificar errores
    usart_tx(0x0D);                             // Nueva l�nea
}

/* Funci�n para enviar reconocimiento de lectura */
char twi_read_ack(void)
{
    TWCR = (1<<TWEN)|(1<<TWINT)|(1<<TWEA);      // Condici�n de reconocimiento seg�n hoja de datos
    while (!(TWCR & (1<<TWINT)));               // Esperar hasta que la condici�n de reconocimiento se transmita al esclavo
    while(TW_STATUS != TW_MR_DATA_ACK);         // Verificar el reconocimiento
    usart_msg("Receiving MR data ACK ");        // Mensaje de retroalimentaci�n para verificar errores
    usart_tx(0x0D);                             // Nueva l�nea
    return TWDR;                                // Devolver datos recibidos del esclavo
}

/* Funci�n para enviar no reconocimiento de lectura */
char twi_read_nack(void)
{
    TWCR = (1<<TWEN)|(1<<TWINT);                // Condici�n de no reconocimiento seg�n hoja de datos
    while (!(TWCR & (1<<TWINT)));               // Esperar hasta que la condici�n de no reconocimiento se transmita al esclavo
    while(TW_STATUS != TW_MR_DATA_NACK);        // Verificar el reconocimiento
    usart_msg("Receiving MR Data NACK");        // Mensaje de retroalimentaci�n para verificar errores
    usart_tx(0x0D);                             // Nueva l�nea
    return TWDR;                                // Devolver datos recibidos
}

/* Funci�n para inicializar USART */
void usart_init(void)
{
    UBRRH = 0;                                  // USART Baud Rate configurado a 115200
    UBRRL = 0x08;    
    UCSRC = (1<<URSEL) | (1<<UCSZ1) | (1<<UCSZ0); // 8-Bit datos seleccionado
    UCSRB = (1<<TXEN) | (1<<RXEN);              // Habilitar TX & RX
}

/* Funci�n para transmitir datos */
void usart_tx(char x)
{
    while (!(UCSRA & (1<<UDRE)));               // Verificar si el b�fer est� vac�o
    UDR = x;                                    // Enviar datos al b�fer USART
}

/* Funci�n para recibir datos */
unsigned char usart_rx(void)
{
    while(!(UCSRA & (1<<RXC)));                 // Verificar si se complet� la recepci�n de datos
    return(UDR);                                // Devolver los datos recibidos
}

/* Funci�n para transmitir cadena */
void usart_msg(char *c)
{
    while(*c != '\0')                           // Verificar si es nulo
        usart_tx(*c++);                         // Enviar la cadena
}