/**
 * lcd_utils.c
 * Implementaci�n de utilidades para manejo de la pantalla LCD
 */

#include "lcd_utils.h"
#include "mfrc522.h"
#include "twi_lcd.h"
#include <string.h>


// Convertir byte a representaci�n hexadecimal
void byteToHex(uint8_t value, char* hexString) {
    const char hex[] = "0123456789ABCDEF";
    hexString[0] = hex[value >> 4];
    hexString[1] = hex[value & 0x0F];
    hexString[2] = '\0';
}

// Mostrar UID en la pantalla LCD
void displayUID_LCD(uint8_t reader) {
    char uidString[17];
    char hexByte[3];
    Uid* currentUID = getCardUID(reader);
    
    twi_lcd_cmd(0x01);
    
    // Mostrar de qu� sensor es
    if (reader == 1) {
        twi_lcd_msg("S1 UID:");
    } else {
        twi_lcd_msg("S2 UID:");
    }
    
    twi_lcd_cmd(0xC0);
    
    uidString[0] = '\0';
    
    for(uint8_t i = 0; i < currentUID->size && i < 5; i++) {
        byteToHex(currentUID->uidByte[i], hexByte);
        strcat(uidString, hexByte);
        if (i < currentUID->size - 1 && i < 4) {
            strcat(uidString, " ");
        }
    }
    
    twi_lcd_msg(uidString);
}

// Mostrar resultado de acceso en la LCD
void displayAccessResult(uint8_t access_granted) {
    twi_lcd_cmd(0x01);
    
    if (access_granted) {
        twi_lcd_msg("Acceso");
        twi_lcd_cmd(0xC0);
        twi_lcd_msg("Otorgado");
		OCR1A = 90;  // Posici�n abierta (ajustar seg�n tu servo)
		_delay_ms(3000); // Mantener abierto por 3 segundos
		ICR1 = 0;
		// Volver a posici�n cerrada
		OCR1A = 65;
    } else {
        twi_lcd_msg("Acceso");
        twi_lcd_cmd(0xC0);
        twi_lcd_msg("Denegado");
    }
}