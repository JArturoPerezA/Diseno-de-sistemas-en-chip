/**
 * keypad.h
 * Interfaz para el manejo de teclado matricial 4x4 usando PORTA
 */

#ifndef KEYPAD_H
#define KEYPAD_H

#include <avr/io.h>
#include <util/delay.h>

// Definiciones para el teclado
#define KEYPAD_PORT     PORTA    // Puerto para el teclado
#define KEYPAD_DDR      DDRA     // Registro de direcci�n de datos
#define KEYPAD_PIN      PINA     // Registro para leer el puerto

#define KEYPAD_ROWS     0x0F     // PA0-PA3: Filas (salidas)
#define KEYPAD_COLS     0xF0     // PA4-PA7: Columnas (entradas)

// Inicializar el teclado
void keypad_init(void);

// Escanear el teclado y retornar la tecla presionada
// Retorna: 0-9 para n�meros, 10 para '*', 11 para '#', 0xFF si no hay tecla
uint8_t keypad_scan(void);

// Convierte el c�digo de escaneo a car�cter
char keypad_map_to_char(uint8_t key_code);

// Obtener entrada del teclado y mostrarla en LCD hasta que se presione #
void keypad_get_input(void);
void keypad_debug_scan(void);
#endif /* KEYPAD_H */