/**
 * keypad.c - Versi�n corregida manteniendo el algoritmo original
 * Implementaci�n del manejo de teclado matricial 4x4 usando PORTA
 */

#include "keypad.h"
#include "twi_lcd.h"

void keypad_init(void) {
    // Configurar PA0-PA3 como salidas (filas) y PA4-PA7 como entradas (columnas)
    KEYPAD_DDR |= KEYPAD_ROWS;    // PA0-PA3 como salidas
    KEYPAD_DDR &= ~KEYPAD_COLS;   // PA4-PA7 como entradas
    
    // Habilitar resistencias pull-up en los pines de columnas (entradas)
    KEYPAD_PORT |= KEYPAD_COLS;
    
    // Inicialmente, todas las filas est�n en alto (inactivas)
    KEYPAD_PORT |= KEYPAD_ROWS;
}

uint8_t keypad_scan(void) {
    int cont_filas = 4;
    char codigo_barrido = 0b11111110;  // Comenzamos con la primera fila en bajo
    int valor_tecla = 3;  // Valor inicial corregido para mapeo correcto
    int temp;
    
    while (cont_filas != 0) {
        // Aplicar patr�n de escaneo manteniendo pull-ups en columnas
        // CORRECCI�N: Preservar el estado de las columnas (pull-ups)
        KEYPAD_PORT = (KEYPAD_PORT & KEYPAD_COLS) | (codigo_barrido & KEYPAD_ROWS);
        
        // CORRECCI�N: Peque�a pausa para estabilizar la se�al
        _delay_us(10);
        
        // Leer estado de columnas
        temp = KEYPAD_PIN & KEYPAD_COLS;
        
        if (temp == KEYPAD_COLS) {  // Ninguna tecla presionada (todas columnas en alto)
            codigo_barrido = (codigo_barrido << 1) | 1;
            valor_tecla = valor_tecla + 4;
            cont_filas--;
            
            if (cont_filas == 0) {
                valor_tecla = 0xFF;  // No hay tecla presionada
                break;
            }
        } else {
            // CORRECCI�N: Aumentar tiempo de debounce
            _delay_ms(20);  // Debounce m�s robusto
            temp = KEYPAD_PIN & KEYPAD_COLS;
            
            if (temp == KEYPAD_COLS) {
                valor_tecla = 0xFF;  // Detecci�n espuria
                break;
            } else if (temp == 0b01110000) {
                // No cambiar valor_tecla (primera columna)
            } else if (temp == 0b10110000) {
                valor_tecla = valor_tecla - 1;  // Segunda columna
            } else if (temp == 0b11010000) {
                valor_tecla = valor_tecla - 2;  // Tercera columna
            } else if (temp == 0b11100000) {
                valor_tecla = valor_tecla - 3;  // Cuarta columna
            } else {
                // CORRECCI�N: Manejar casos donde m�ltiples columnas est�n activas
                valor_tecla = 0xFF;  // Detecci�n inv�lida
                break;
            }
            
            // Esperar a que se suelte la tecla
            while ((KEYPAD_PIN & KEYPAD_COLS) != KEYPAD_COLS) {
                _delay_ms(1);  // CORRECCI�N: Peque�a pausa en el bucle de espera
            }
            
            _delay_ms(20);  // CORRECCI�N: Debounce despu�s de soltar (aumentado)
            cont_filas = 0;
        }
    }
    
    // Restaurar estado de filas (todas en alto)
    KEYPAD_PORT |= KEYPAD_ROWS;
    
    return valor_tecla;
}

// Mapear c�digos de escaneo a caracteres - CORREGIDO con columnas invertidas
char keypad_map_to_char(uint8_t key_code) {
    // Mapeo corregido - las columnas est�n f�sicamente invertidas
    // El algoritmo original cuenta desde 3 y va incrementando
    switch (key_code) {
        case 0:  return '1';  // Fila 0, Columna 3 (f�sicamente columna 0)
        case 1:  return '2';  // Fila 0, Columna 2 (f�sicamente columna 1)
        case 2:  return '3';  // Fila 0, Columna 1 (f�sicamente columna 2)
        case 3:  return 'A';  // Fila 0, Columna 0 (f�sicamente columna 3)
        case 4:  return '4';  // Fila 1, Columna 3 (f�sicamente columna 0)
        case 5:  return '5';  // Fila 1, Columna 2 (f�sicamente columna 1)
        case 6:  return '6';  // Fila 1, Columna 1 (f�sicamente columna 2)
        case 7:  return 'B';  // Fila 1, Columna 0 (f�sicamente columna 3)
        case 8:  return '7';  // Fila 2, Columna 3 (f�sicamente columna 0)
        case 9:  return '8';  // Fila 2, Columna 2 (f�sicamente columna 1)
        case 10: return '9';  // Fila 2, Columna 1 (f�sicamente columna 2)
        case 11: return 'C';  // Fila 2, Columna 0 (f�sicamente columna 3)
        case 12: return '*';  // Fila 3, Columna 3 (f�sicamente columna 0)
        case 13: return '0';  // Fila 3, Columna 2 (f�sicamente columna 1)
        case 14: return '#';  // Fila 3, Columna 1 (f�sicamente columna 2)
        case 15: return 'D';  // Fila 3, Columna 0 (f�sicamente columna 3)
        default: return 0;    // Car�cter nulo para c�digos inv�lidos
    }
}

// Funci�n para obtener y mostrar la entrada del teclado hasta que se presione #
void keypad_get_input(void) {
    uint8_t key;
    char key_char;
    char input_buffer[17] = {0};  // Buffer para almacenar entrada (16 caracteres m�x + null)
    uint8_t input_pos = 0;
    
    // Limpiar pantalla
    twi_lcd_cmd(0x01);
    _delay_ms(2);  // CORRECCI�N: Esperar que se complete el comando clear
    
    twi_lcd_msg("Ingrese Codigo:");
    twi_lcd_cmd(0xC0);  // Moverse a la segunda l�nea
    
    while (1) {
        key = keypad_scan();
        
        // Si se presion� una tecla
        if (key != 0xFF) {
            key_char = keypad_map_to_char(key);
            
            // CORRECCI�N: Verificar que el car�cter sea v�lido
            if (key_char == 0) {
                continue;  // Ignorar caracteres inv�lidos
            }
            
            // Si se presion� #, salir
            if (key_char == '#') {
                break;
            }
            
            // CORRECCI�N: Manejar la tecla * como borrar
            if (key_char == '*' && input_pos > 0) {
                input_pos--;
                input_buffer[input_pos] = 0;
                
                // Limpiar la segunda l�nea y reescribir
                twi_lcd_cmd(0xC0);  // Moverse a la segunda l�nea
                twi_lcd_msg("                "); // 16 espacios
                twi_lcd_cmd(0xC0);  // Volver al inicio de segunda l�nea
                if (input_pos > 0) {
                    twi_lcd_msg(input_buffer);
                }
            }
            // Manejar otras teclas
            else if (key_char != '*' && input_pos < 16) {  // Asegurar que no desbordamos la l�nea LCD
                // A�adir al buffer
                input_buffer[input_pos] = key_char;
                input_pos++;
                input_buffer[input_pos] = 0;  // Null terminator
                
                // CORRECCI�N: Actualizar LCD de forma m�s eficiente
                // Moverse a la posici�n exacta y escribir solo el nuevo car�cter
                twi_lcd_cmd(0xC0 + input_pos - 1);
                char single_char[2] = {key_char, 0};
                twi_lcd_msg(single_char);
            }
        }
        
        _delay_ms(50);  // CORRECCI�N: Tasa de escaneo ajustada para evitar lecturas m�ltiples
    }
    
    // Limpiar pantalla al terminar
    twi_lcd_cmd(0x01);
    _delay_ms(2);
    twi_lcd_msg("Codigo Ingresado:");
    twi_lcd_cmd(0xC0);
    twi_lcd_msg(input_buffer);
    _delay_ms(2000);
}

// FUNCI�N ADICIONAL DE DEBUG: Mostrar c�digos de escaneo
void keypad_debug_scan(void) {
    twi_lcd_cmd(0x01);
    twi_lcd_msg("Debug Teclado");
    _delay_ms(1000);
    
    while (1) {
        uint8_t key = keypad_scan();
        if (key != 0xFF) {
            char key_char = keypad_map_to_char(key);
            
            twi_lcd_cmd(0x01);
            twi_lcd_msg("Cod:");
            
            // Mostrar c�digo num�rico
            char code_str[4];
            if (key < 10) {
                code_str[0] = '0';
                code_str[1] = '0' + key;
                code_str[2] = 0;
            } else {
                code_str[0] = '0' + (key / 10);
                code_str[1] = '0' + (key % 10);
                code_str[2] = 0;
            }
            twi_lcd_msg(code_str);
            
            twi_lcd_cmd(0xC0);
            twi_lcd_msg("Char:");
            if (key_char != 0) {
                char char_str[2] = {key_char, 0};
                twi_lcd_msg(char_str);
            } else {
                twi_lcd_msg("INV");
            }
            
            _delay_ms(1500);
        }
        _delay_ms(50);
    }
}