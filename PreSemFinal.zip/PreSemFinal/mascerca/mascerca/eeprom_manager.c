/**
 * eeprom_manager.c
 * Implementaci�n de funciones para gesti�n de UIDs en EEPROM
 */

#include "eeprom_manager.h"
#include "mfrc522.h"
#include "twi_lcd.h"
#include "lcd_utils.h"
#include <avr/io.h>
#include <string.h>

// Funciones de acceso a EEPROM
void EEPROM_write(unsigned int uiAddress, unsigned char ucData) {
    while(EECR & (1<<EEWE));
    EEAR = uiAddress;
    EEDR = ucData;
    EECR |= (1<<EEMWE);
    EECR |= (1<<EEWE);
}

unsigned char EEPROM_read(unsigned int uiAddress) {
    while(EECR & (1<<EEWE));
    EEAR = uiAddress;
    EECR |= (1<<EERE);
    return EEDR;
}

// Inicializar EEPROM si es la primera vez
void initializeEEPROM(void) {
    if (EEPROM_read(EEPROM_START_ADDRESS - 1) != 0xAA) {
        for (uint16_t i = 0; i < (MAX_AUTHORIZED_UIDS * EEPROM_BLOCK_SIZE); i++) {
            EEPROM_write(EEPROM_START_ADDRESS + i, 0xFF);
        }
        EEPROM_write(EEPROM_START_ADDRESS - 1, 0xAA);
    }
}

// Verificar si una UID es v�lida
uint8_t isValidUID(uint8_t* uid) {
    for (uint8_t i = 0; i < UID_SIZE; i++) {
        if (uid[i] != 0xFF && uid[i] != 0x00) {
            return 1;
        }
    }
    return 0;
}

// Buscar el pr�ximo slot libre en EEPROM
uint8_t getNextFreeSlot(void) {
    uint8_t temp_uid[UID_SIZE];
    
    for (uint8_t slot = 0; slot < MAX_AUTHORIZED_UIDS; slot++) {
        for (uint8_t i = 0; i < UID_SIZE; i++) {
            temp_uid[i] = EEPROM_read(EEPROM_START_ADDRESS + (slot * EEPROM_BLOCK_SIZE) + i);
        }
        
        if (!isValidUID(temp_uid)) {
            return slot;
        }
    }
    
    return 0xFF;
}

// Verificar si la UID actual est� autorizada
uint8_t checkUID_Authorization(void) {
    uint8_t temp_uid[UID_SIZE];
    uint8_t match;
    Uid* cardUID1 = getCardUID(1);
    
    for (uint8_t slot = 0; slot < MAX_AUTHORIZED_UIDS; slot++) {
        for (uint8_t i = 0; i < UID_SIZE; i++) {
            temp_uid[i] = EEPROM_read(EEPROM_START_ADDRESS + (slot * EEPROM_BLOCK_SIZE) + i);
        }
        
        if (isValidUID(temp_uid)) {
            match = 1;
            for (uint8_t i = 0; i < UID_SIZE; i++) {
                if (cardUID1->uidByte[i] != temp_uid[i]) {
                    match = 0;
                    break;
                }
            }
            
            if (match) {
                return 1;
            }
        }
    }
    
    return 0;
}

// Agregar nueva UID a EEPROM
uint8_t addUID_ToEEPROM(uint8_t* uid) {
    uint8_t free_slot = getNextFreeSlot();
    
    if (free_slot == 0xFF) {
        return 0;
    }
    
    for (uint8_t i = 0; i < UID_SIZE; i++) {
        EEPROM_write(EEPROM_START_ADDRESS + (free_slot * EEPROM_BLOCK_SIZE) + i, uid[i]);
    }
    
    return 1;
}

// Mostrar cantidad de UIDs autorizadas
void displayAuthorizedCount(void) {
    uint8_t count = 0;
    uint8_t temp_uid[UID_SIZE];
    char count_str[17];
    
    for (uint8_t slot = 0; slot < MAX_AUTHORIZED_UIDS; slot++) {
        for (uint8_t i = 0; i < UID_SIZE; i++) {
            temp_uid[i] = EEPROM_read(EEPROM_START_ADDRESS + (slot * EEPROM_BLOCK_SIZE) + i);
        }
        if (isValidUID(temp_uid)) {
            count++;
        }
    }
    
    twi_lcd_cmd(0x01);
    twi_lcd_msg("UIDs autorizadas:");
    twi_lcd_cmd(0xC0);
    
    if (count == 0) {
        strcpy(count_str, "0");
    } else {
        uint8_t temp = count;
        uint8_t digits = 0;
        
        while (temp > 0) {
            digits++;
            temp /= 10;
        }
        
        count_str[digits] = '\0';
        temp = count;
        
        for (int8_t i = digits - 1; i >= 0; i--) {
            count_str[i] = '0' + (temp % 10);
            temp /= 10;
        }
    }
    
    strcat(count_str, " de ");
    
    char max_str[4];
    uint8_t max_temp = MAX_AUTHORIZED_UIDS;
    uint8_t max_digits = 0;
    
    while (max_temp > 0) {
        max_digits++;
        max_temp /= 10;
    }
    
    max_str[max_digits] = '\0';
    max_temp = MAX_AUTHORIZED_UIDS;
    
    for (int8_t i = max_digits - 1; i >= 0; i--) {
        max_str[i] = '0' + (max_temp % 10);
        max_temp /= 10;
    }
    
    strcat(count_str, max_str);
    twi_lcd_msg(count_str);
}